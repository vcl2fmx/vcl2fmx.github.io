{VCL2FMX © 2026 echurchsites.wixsite.com
 Delphi VCL to FMX Converter and assistant
 Version v7.0 Atlas
 Written and built in the USA}

unit Converter.Core.Engine;

interface

uses
  System.SysUtils,
  System.Classes,
  System.IOUtils,
  System.StrUtils,
  System.Math,
  System.DateUtils,
  System.Generics.Collections,
  System.Generics.Defaults,
  System.RegularExpressions,
  System.NetEncoding,
    FMX.Forms,
    System.Types,
  Converter.Core.Types,
  Converter.Core.FileManager,
  Converter.Core.Integration,
  Converter.Project.Generator,
  Converter.Reporting.Html,
  Converter.Reporting.Json,
  Converter.Reporting.Model,
  Converter.Reporting.Strings,
  Converter.Reporting.Text;

type
  TConverterEngine = class
  private
    FContext: TConversionContext;
    FFileManager: TFileManager;
    FOrchestrator: TConversionOrchestrator;
    FProjectGenerator: TProjectGenerator;

    FCancelled: Boolean;
    FFilesProcessed: Integer;
    FFilesConverted: Integer;
    FFilesErrors: Integer;
    FFilesSkipped: Integer;

    FConversionLog: TStringList;
    FStartTime: TDateTime;
    FEndTime: TDateTime;
    FLogCallback: TProc<string>;
    FTextReportPath: string;
    FHtmlReportPath: string;
    FReportTextTranslator: TFunc<string, string>;
    FReportHtmlTranslator: TFunc<string, string>;
    FReportLanguageCode: string;
    FReportTextDirection: string;

    procedure ProcessPasFile(const AFileName: string);
    procedure ProcessDfmFile(const AFileName: string);
    procedure AuditDfmFmxFidelity(const AFileName, ASourceDfm,
      AGeneratedFmx: string);
    procedure ScanPascalIncludeDirectives(const AFileName, ACode: string);
    procedure CopyPascalIncludeFile(const ASourcePasFile, AIncludePath,
      AIncludeName: string; ALine: Integer);
    procedure GenerateReport;
    procedure AddHtmlReportDocumentHead(const AHtml: TStrings);
    procedure AuditGeneratedOutput;
    procedure AuditGeneratedFile(const AFileName: string);
    procedure BuildCrossUnitSemanticIndex;
    procedure ExportMappingPackAuthoringSuggestions;
    procedure UILog(const Msg: string; const ForceScreen: Boolean = True); overload;
    procedure UILog(const ScreenMsg, LogMsg: string;
      const ForceScreen: Boolean = True); overload;
    procedure LogToFile(const Msg: string);
    procedure RebuildServicesForContext(AContext: TConversionContext);
    function TryReadWithEncoding(const AFileName: string; out Code: string): Boolean;
    function SeverityToString(Severity: TConversionSeverity): string;

  public
    constructor Create(AContext: TConversionContext);
    destructor Destroy; override;

    function Convert(AContext: TConversionContext): Boolean;
    procedure Cancel;

    property LogCallback: TProc<string> read FLogCallback write FLogCallback;
    property FilesProcessed: Integer read FFilesProcessed;
    property FilesConverted: Integer read FFilesConverted;
    property FilesWithErrors: Integer read FFilesErrors;
    property FilesSkipped: Integer read FFilesSkipped;
    property StartTime: TDateTime read FStartTime;
    property EndTime: TDateTime read FEndTime;
    property TextReportPath: string read FTextReportPath;
    property HtmlReportPath: string read FHtmlReportPath;
    property ReportTextTranslator: TFunc<string, string> read FReportTextTranslator write FReportTextTranslator;
    property ReportHtmlTranslator: TFunc<string, string> read FReportHtmlTranslator write FReportHtmlTranslator;
    property ReportLanguageCode: string read FReportLanguageCode write FReportLanguageCode;
    property ReportTextDirection: string read FReportTextDirection write FReportTextDirection;
  end;

implementation


resourcestring
  SDisplayReadingS = '  Reading %s...';
  SDisplayEncodingS = '  Encoding: %s';
  SDisplayFailedCouldNotReadFileWithSupported = '  FAILED: Could not read file with supported encodings';
  SDisplayScreenMemoConnected = 'Screen memo connected';
  SDisplayVclToFmxConversionStarted = 'VCL TO FMX CONVERSION STARTED';
  SDisplaySourceS = 'Source: %s';
  SDisplayOutputS = 'Output: %s';
  SDisplayFoundDFilesToProcess = 'Found %d files to process';
  SDisplayDDProcessingS = '[%d/%d] Processing: %s';
  SDisplayFailedS = '  FAILED: %s';
  SDisplayFailedSS = '  FAILED: %s - %s';
  SDisplayDryRunPreviewConvertedSourceAndProject = 'Dry-run preview: converted source and project generation skipped';
  SDisplayDryRunPreviewReportsAndMappingSuggestions = 'Dry-run preview reports and mapping suggestions will still be written for review';
  SDisplayGeneratingProjectFiles = 'Generating project files...';
  SDisplayProjectFilesGenerated = 'Project files generated';
  SDisplayConversionCompletedWithBlockingIssuesOpenThe = 'Conversion completed with blocking issues. Open the report, fix blocking items first, then review the generated output in the IDE.';
  SDisplayConversionCompletedWithManualReviewRequiredOpen = 'Conversion completed with manual review required. Open the report, review the grouped manual-review items, and verify the generated code in the IDE.';
  SDisplayConversionCompletedCleanlyOpenTheReportFor = 'Conversion completed cleanly. Open the report for a final sanity check before using the output.';
  SDisplayFatalErrorS = 'FATAL ERROR: %s';
  SDisplayProcessingPascalFileS = 'Processing Pascal file: %s';
  SDisplayProcessingPascalS = 'Processing Pascal: %s';
  SDisplayFailedCouldNotReadFile = '  FAILED: Could not read file';
  SDisplayConverted = '  Converted';
  SDisplayFailed = '  FAILED';
  SDisplayFailedConvertedPascalFileWasNotSaved = '  FAILED: Converted Pascal file was not saved';
  SDisplaySkippedSavePascalConversionDidNotProduce = '  SKIPPED SAVE: Pascal conversion did not produce safe output';
  SDisplayProcessingDfmFileS = 'Processing DFM file: %s';
  SDisplayProcessingDfmS = 'Processing DFM: %s';
  SDisplayFailedDfmFileIsTooLargeFor = '  FAILED: DFM file is too large for safe automatic parsing';
  SDisplayFailedUnableToReadDfmSourceText = '  FAILED: unable to read DFM source text';
  SDisplayDetectingDfmStreamFormat = '  Detecting DFM stream format...';
  SDisplayFailedConvertedDfmFileWasNotSaved = '  FAILED: Converted DFM file was not saved';
  SDisplaySkippedSaveDfmConversionDidNotProduce = '  SKIPPED SAVE: DFM conversion did not produce safe output';
  SDisplayReportSavedToS = 'Report saved to: %s';
  SDisplayHtmlReportSavedToS = 'HTML report saved to: %s';
  SDisplayJsonReportSavedToS = 'JSON report saved to: %s';
  SDisplayConversionCancelledByUser = 'Conversion cancelled by user';

constructor TConverterEngine.Create(AContext: TConversionContext);
begin
  inherited Create;
  if not Assigned(AContext) then
    raise EArgumentNilException.Create('Conversion context is not assigned');
  FContext := AContext;
  FCancelled := False;
  FLogCallback := nil;
  FFilesProcessed := 0;
  FFilesConverted := 0;
  FFilesErrors := 0;
  FFilesSkipped := 0;
  FConversionLog := TStringList.Create;
end;

destructor TConverterEngine.Destroy;
begin
  FConversionLog.Free;
  FProjectGenerator.Free;
  FOrchestrator.Free;
  FFileManager.Free;
  inherited;
end;

procedure TConverterEngine.RebuildServicesForContext(AContext: TConversionContext);
begin
  if not Assigned(AContext) then
    raise EArgumentNilException.Create('Conversion context is not assigned');

  FreeAndNil(FProjectGenerator);
  FreeAndNil(FOrchestrator);
  FreeAndNil(FFileManager);

  FContext := AContext;
  FFileManager := TFileManager.Create(FContext);
  FOrchestrator := TConversionOrchestrator.Create(FContext);
  FProjectGenerator := TProjectGenerator.Create(FContext);
end;

function TConverterEngine.SeverityToString(Severity: TConversionSeverity): string;
begin
  case Severity of
    csInfo: Result := 'INFO';
    csWarning: Result := 'WARNING';
    csManualReview: Result := 'MANUAL REVIEW';
    csError: Result := 'ERROR';
    csCritical: Result := 'CRITICAL';
  else
    Result := 'UNKNOWN';
  end;
end;

procedure TConverterEngine.UILog(const Msg: string; const ForceScreen: Boolean = True);
begin
  UILog(Msg, Msg, ForceScreen);
end;

procedure TConverterEngine.UILog(const ScreenMsg, LogMsg: string;
  const ForceScreen: Boolean = True);
begin
  if Assigned(FLogCallback) and ForceScreen then
    FLogCallback(ScreenMsg);

  // Also log to file
  LogToFile(LogMsg);
end;

procedure TConverterEngine.LogToFile(const Msg: string);
begin
  FConversionLog.Add(Format('[%s] %s', [FormatDateTime('hh:nn:ss', Now), Msg]));
end;

function TConverterEngine.TryReadWithEncoding(const AFileName: string; out Code: string): Boolean;
var
  EncodingName: string;
begin
  UILog(Format(SDisplayReadingS, [ExtractFileName(AFileName)]));
  Result := VCL2FMXTryReadTextFile(AFileName, Code, EncodingName);
  if Result then
    UILog(Format(SDisplayEncodingS, [EncodingName]))
  else
    UILog(SDisplayFailedCouldNotReadFileWithSupported);
end;
procedure TConverterEngine.AuditGeneratedFile(const AFileName: string);
var
  Lines: TStringList;
  Ext: string;
  I: Integer;
  Line: string;
  CodeLine: string;
  FullCode: string;
  Trimmed: string;
  OriginalTrimmed: string;
  LastSignificantLine: string;
  InBraceComment: Boolean;
  InParenComment: Boolean;
  EncodingName: string;

  procedure AddGeneratedReview(const AProblemType, AMessage, ASuggestedFix: string;
    AIsBlocking: Boolean = False);
  var
    Issue: TConversionIssue;
  begin
    Issue := TConversionIssue.Create(csManualReview, AMessage);
    Issue.FileName := AFileName;
    Issue.LineNumber := I + 1;
    Issue.ProblemType := AProblemType;
    Issue.OriginalCode := TrimRight(Line);
    Issue.SuggestedFix := ASuggestedFix;
    Issue.IsBlocking := AIsBlocking;
    FContext.AddIssue(Issue);
  end;

  function IsPascalCommentLine(const S: string): Boolean;
  begin
    Result := StartsText('//', S) or StartsText('{', S) or StartsText('(*', S);
  end;

  function StripPascalCommentsFromLine(const S: string;
    var AInBraceComment, AInParenComment: Boolean): string;
  var
    P: Integer;
    Ch: Char;
    InString: Boolean;
  begin
    Result := '';
    P := 1;
    InString := False;
    while P <= Length(S) do
    begin
      if AInBraceComment then
      begin
        if S[P] = '}' then
          AInBraceComment := False;
        Inc(P);
        Continue;
      end;

      if InString then
      begin
        Ch := S[P];
        Result := Result + Ch;
        if Ch = '''' then
        begin
          if (P < Length(S)) and (S[P + 1] = '''') then
          begin
            Result := Result + S[P + 1];
            Inc(P, 2);
            Continue;
          end;
          InString := False;
        end;
        Inc(P);
        Continue;
      end;

      if S[P] = '''' then
      begin
        InString := True;
        Result := Result + S[P];
        Inc(P);
        Continue;
      end;

      if AInParenComment then
      begin
        if (S[P] = '*') and (P < Length(S)) and (S[P + 1] = ')') then
        begin
          AInParenComment := False;
          Inc(P, 2);
        end
        else
          Inc(P);
        Continue;
      end;

      if (S[P] = '/') and (P < Length(S)) and (S[P + 1] = '/') then
        Break;

      if S[P] = '{' then
      begin
        AInBraceComment := True;
        Inc(P);
        Continue;
      end;

      if (S[P] = '(') and (P < Length(S)) and (S[P + 1] = '*') then
      begin
        AInParenComment := True;
        Inc(P, 2);
        Continue;
      end;

      Ch := S[P];
      Result := Result + Ch;
      Inc(P);
    end;
  end;

  function StripCommentPrefix(const S, Prefix: string): string;
  begin
    Result := Trim(S);
    while StartsText(Prefix, Result) do
      Result := Trim(Copy(Result, Length(Prefix) + 1, MaxInt));
  end;

  function LooksLikeCommentedPascalCode(const S: string): Boolean;
  var
    ReviewText: string;
  begin
    ReviewText := Trim(LowerCase(S));
    Result :=
      (ReviewText = '') or
      StartsText('procedure ', ReviewText) or
      StartsText('function ', ReviewText) or
      StartsText('constructor ', ReviewText) or
      StartsText('destructor ', ReviewText) or
      StartsText('class procedure ', ReviewText) or
      StartsText('class function ', ReviewText) or
      StartsText('begin', ReviewText) or
      StartsText('end', ReviewText) or
      StartsText('if ', ReviewText) or
      StartsText('else', ReviewText) or
      StartsText('try', ReviewText) or
      StartsText('except', ReviewText) or
      StartsText('finally', ReviewText) or
      StartsText('case ', ReviewText) or
      StartsText('for ', ReviewText) or
      StartsText('while ', ReviewText) or
      StartsText('repeat', ReviewText) or
      StartsText('until ', ReviewText) or
      StartsText('with ', ReviewText) or
      StartsText('inherited', ReviewText) or
      StartsText('exit', ReviewText) or
      TRegEx.IsMatch(ReviewText, '^[a-z_][a-z0-9_]*\s*:', [roIgnoreCase]) or
      ContainsText(ReviewText, ':=') or
      ContainsText(ReviewText, '(') or
      ContainsText(ReviewText, ')') or
      ContainsText(ReviewText, ';');
  end;

  function UsesIntegerDivOnFmxSizeValue(const S: string): Boolean;
  var
    AssignPos: Integer;
    RHS: string;
  begin
    AssignPos := Pos(':=', S);
    if AssignPos > 0 then
      RHS := Copy(S, AssignPos + 2, MaxInt)
    else
      RHS := S;

    Result := TRegEx.IsMatch(RHS,
      '(\.\s*(Width|Height)|\bClientWidth\b|\bClientHeight\b)[^;]*\bdiv\b|' +
      '\bdiv\b[^;]*(\.\s*(Width|Height)|\bClientWidth\b|\bClientHeight\b)',
      [roIgnoreCase]);
  end;

  function GetPerformReplacementSuggestion(const S: string): string;
  begin
    if TRegEx.IsMatch(S, '\bEM_SETSEL\b', [roIgnoreCase]) then
      Result := 'Replace EM_SETSEL with FMX memo selection code. For TMemo, review CaretPosition and selection APIs in the IDE; for TEdit, use SelStart/SelLength where available.'
    else if TRegEx.IsMatch(S, '\bEM_LINESCROLL\b|\bEM_SCROLLCARET\b', [roIgnoreCase]) then
      Result := 'Replace EM_LINESCROLL/EM_SCROLLCARET with FMX memo scrolling behavior. Prefer moving the caret/selection into view or using the memo viewport/scroll-box support exposed by the target FMX control.'
    else if TRegEx.IsMatch(S, '\bEM_LINEFROMCHAR\b|\bEM_LINEINDEX\b', [roIgnoreCase]) then
      Result := 'Replace EM_LINEFROMCHAR/EM_LINEINDEX with an FMX helper that derives the line from memo text and caret position; VCL line-message return values do not carry over directly.'
    else if TRegEx.IsMatch(S, '\bLB_SELECTSTRING\b', [roIgnoreCase]) then
      Result := 'Replace LB_SELECTSTRING with an FMX list search: loop through Items, compare text, and assign ItemIndex when a match is found.'
    else if TRegEx.IsMatch(S, '\bWM_SYSCOMMAND\b', [roIgnoreCase]) then
      Result := 'Replace WM_SYSCOMMAND Perform calls by mapping the specific SC_* command to FMX form logic such as Close, WindowState, OnCloseQuery, or platform-specific code.'
    else
      Result := 'Replace this VCL Perform(...) message dispatch with the equivalent FMX control API, event, or platform-specific code for the specific message being sent.';
  end;
  procedure AddGeneratedCommentReviewIfNeeded(const ATrimmed: string);
  var
    ReviewText: string;
  begin
    if StartsText('// FMX manual review:', ATrimmed) then
    begin
      ReviewText := StripCommentPrefix(ATrimmed, '// FMX manual review:');

      if SameText(ReviewText, 'TLayout has no TextSettings') then
        AddGeneratedReview(
          'Unsupported text-settings target',
          'Generated code attempted to map text settings onto TLayout, which does not expose TextSettings in FMX.',
          'Review this generated code manually and move the text styling to an FMX text control if needed.',
          False)
      else if not LooksLikeCommentedPascalCode(ReviewText) then
        AddGeneratedReview(
          'Generated manual-review note',
          'Generated code includes a converter manual-review note: ' + ReviewText,
          'Review this note in the IDE and complete the missing FMX behavior manually where needed.',
          False);
    end;
  end;

begin
  if not TFile.Exists(AFileName) then
    Exit;

  Ext := LowerCase(ExtractFileExt(AFileName));
  if not MatchText(Ext, ['.pas', '.dpr', '.fmx']) then
    Exit;

  Lines := TStringList.Create;
  try
    if not VCL2FMXTryReadTextFile(AFileName, CodeLine, EncodingName) then
    begin
      FContext.AddIssue(csWarning,
        'Generated file could not be audited because it could not be read: ' +
          ExtractFileName(AFileName),
        'Generated output audit read failure',
        '',
        'Open the generated file in the IDE and verify it manually.',
        -1,
        False);
      Exit;
    end;
    FullCode := CodeLine;
    Lines.Text := FullCode;
    LastSignificantLine := '';
    InBraceComment := False;
    InParenComment := False;
    for I := 0 to Lines.Count - 1 do
    begin
      Line := Lines[I];
      OriginalTrimmed := Trim(Line);
      CodeLine := Line;
      if MatchText(Ext, ['.pas', '.dpr']) then
        CodeLine := StripPascalCommentsFromLine(Line, InBraceComment, InParenComment);
      Trimmed := Trim(CodeLine);
      if (OriginalTrimmed = '') and (Trimmed = '') then
        Continue;

      if MatchText(Ext, ['.pas', '.dpr']) then
      begin
        if IsPascalCommentLine(OriginalTrimmed) then
        begin
          AddGeneratedCommentReviewIfNeeded(OriginalTrimmed);
          Continue;
        end;

        if Trimmed = '' then
          Continue;

        LastSignificantLine := Trimmed;

        if TRegEx.IsMatch(Trimmed, ':\s*TBitBtn\b', [roIgnoreCase]) then
          AddGeneratedReview(
            'Leftover VCL declaration in generated Pascal',
            'Generated Pascal still declares a VCL TBitBtn.',
            'Replace the declaration with TButton or the FMX equivalent before compiling.',
            True);

        if TRegEx.IsMatch(Trimmed, '\bVcl\.', [roIgnoreCase]) then
          AddGeneratedReview(
            'Leftover VCL unit reference in generated Pascal',
            'Generated Pascal still references a Vcl.* unit namespace.',
            'Replace the remaining Vcl.* reference with the correct FMX or System unit before compiling.',
            True);

        if TRegEx.IsMatch(Trimmed, '^\{\$R\s+\*\.DFM\}', [roIgnoreCase]) then
          AddGeneratedReview(
            'VCL form resource directive in generated Pascal',
            'Generated Pascal still references {$R *.DFM}.',
            'Change this resource directive to {$R *.fmx} or rerun after correcting the converter rewrite path.',
            True);

        if TRegEx.IsMatch(Trimmed, '^\s*(?:class\s+)?(?:procedure|function)\b.*\bmessage\b.*;', [roIgnoreCase]) then
          AddGeneratedReview(
            'VCL message-handler declaration still present',
            'Generated Pascal still declares a VCL-style message-handler method.',
            'Replace this message-based handler with an FMX-safe event or manual-review implementation before compiling.',
            True);

        if TRegEx.IsMatch(Trimmed, ':\s*TTrayIcon\b', [roIgnoreCase]) then
          AddGeneratedReview(
            'Unsupported component still emitted in generated Pascal',
            'Generated Pascal still declares TTrayIcon.',
            'Remove or replace this tray icon code manually. FMX has no standard tray icon component.',
            True);

        if TRegEx.IsMatch(Trimmed, ':\s*TApdComPort\b', [roIgnoreCase]) then
          AddGeneratedReview(
            'Unsupported component still emitted in generated Pascal',
            'Generated Pascal still declares TApdComPort.',
            'Replace this third-party serial component with a manual FMX or WinAPI-based implementation.',
            True);

        if ContainsText(Trimmed, 'Application.ShowMainForm') then
          AddGeneratedReview(
            'VCL-only project startup code',
            'Generated code still contains Application.ShowMainForm, which is not valid FMX startup logic here.',
            'Remove this line and review the project startup flow manually.',
            True);

        if ContainsText(Trimmed, 'Application.BringToFront') then
          AddGeneratedReview(
            'VCL-only application call',
            'Generated code still calls Application.BringToFront.',
            'Replace this with an FMX-safe form activation path or handle it manually.',
            True);

        if TRegEx.IsMatch(Trimmed, '\.\s*Perform\s*\(', [roIgnoreCase]) then
          AddGeneratedReview(
            'VCL-only runtime method',
            'Generated code still calls Perform(...), which is a VCL message-dispatch pattern.',
            GetPerformReplacementSuggestion(Trimmed),
            True);

        if TRegEx.IsMatch(Trimmed, '\.\s*Invalidate\s*;', [roIgnoreCase]) then
          AddGeneratedReview(
            'VCL-only repaint call',
            'Generated code still calls Invalidate on a control.',
            'Replace this with an FMX repaint/update call that the target control actually supports.',
            True);

        if TRegEx.IsMatch(Trimmed, '\b\w*TrayIcon\w*\.', [roIgnoreCase]) then
          AddGeneratedReview(
            'Unsupported tray icon usage still present',
            'Generated Pascal still contains runtime tray icon usage.',
            'Remove or redesign the tray behavior manually before relying on this output.',
            True);

        if TRegEx.IsMatch(Trimmed, '^\s*(?:Self|AForm)\.Color\s*:=', [roIgnoreCase]) then
          AddGeneratedReview(
            'Leftover VCL color assignment',
            'Generated Pascal still assigns to Color directly.',
            'Review whether this should become Fill.Color, TextSettings.FontColor, or another FMX color property.',
            True);

        if TRegEx.IsMatch(Trimmed, '\bBorderStyle\s*:=\s*bs\w+', [roIgnoreCase]) then
          AddGeneratedReview(
            'Leftover VCL border-style enum',
            'Generated Pascal still assigns a VCL BorderStyle enum value.',
            'Map this to the FMX form/control border model or update the enum usage manually.',
            True);

        if TRegEx.IsMatch(Trimmed, '\bWindowState\s*:=\s*ws\w+', [roIgnoreCase]) then
          AddGeneratedReview(
            'Potential VCL window-state enum usage',
            'Generated Pascal still assigns an unqualified VCL-style WindowState value.',
            'Review this assignment and replace it with the correct FMX window-state usage if needed.',
            True);

        if TRegEx.IsMatch(Trimmed, '\.\s*(Stretch|Proportional)\s*:=', [roIgnoreCase]) then
          AddGeneratedReview(
            'Leftover VCL image property',
            'Generated Pascal still uses a VCL image sizing property.',
            'Review this image behavior and map it to FMX TImage.WrapMode or other FMX image settings manually.',
            True);

        if TRegEx.IsMatch(Trimmed, '\.\s*Picture(\b|[\.\s:=])', [roIgnoreCase]) then
          AddGeneratedReview(
            'Leftover VCL image API',
            'Generated Pascal still uses the VCL Picture API.',
            'Replace this with FMX TImage.Bitmap operations before relying on this output.',
            True);

        if UsesIntegerDivOnFmxSizeValue(Trimmed) then
          AddGeneratedReview(
            'Potential integer division on FMX size values',
            'Generated Pascal uses div with width/height values that are often floating-point in FMX.',
            'Review this expression and consider using / with Round/Trunc where needed.',
            False);
      end
      else if SameText(Ext, '.fmx') then
      begin
        if TRegEx.IsMatch(Trimmed, '^StyleElements\s*=', [roIgnoreCase]) then
          AddGeneratedReview(
            'VCL-only streamed property',
            'Generated FMX stream still contains StyleElements.',
            'Remove this property or replace it with an FMX styling approach.',
            True);

        if TRegEx.IsMatch(Trimmed, '^Style\s*=', [roIgnoreCase]) then
          AddGeneratedReview(
            'VCL-only streamed property',
            'Generated FMX stream still contains a VCL Style property.',
            'Remove or manually map this property to an FMX equivalent.',
            True);

        if TRegEx.IsMatch(Trimmed, '^Stroke\.Style\s*=', [roIgnoreCase]) then
          AddGeneratedReview(
            'VCL-only streamed property',
            'Generated FMX stream still contains Stroke.Style.',
            'Replace this with Stroke.Kind or the correct FMX stroke property.',
            True);

        if TRegEx.IsMatch(Trimmed, '^Shape\s*=', [roIgnoreCase]) then
          AddGeneratedReview(
            'VCL-only streamed property',
            'Generated FMX stream still contains the VCL Shape property.',
            'Replace this by using the correct FMX shape class and remove the VCL Shape setting.',
            True);

        if TRegEx.IsMatch(Trimmed, '^DoubleBuffered\s*=', [roIgnoreCase]) then
          AddGeneratedReview(
            'VCL-only streamed property',
            'Generated FMX stream still contains DoubleBuffered.',
            'Remove this VCL buffering property or review the control behavior manually.',
            True);

        if TRegEx.IsMatch(Trimmed, '^ParentDoubleBuffered\s*=', [roIgnoreCase]) then
          AddGeneratedReview(
            'VCL-only streamed property',
            'Generated FMX stream still contains ParentDoubleBuffered.',
            'Remove this VCL buffering property or review the control behavior manually.',
            True);

        if TRegEx.IsMatch(Trimmed, '^DesignSize\s*=', [roIgnoreCase]) then
          AddGeneratedReview(
            'VCL-only streamed property',
            'Generated FMX stream still contains DesignSize.',
            'Remove this VCL designer-only property and review the layout manually.',
            True);

        if TRegEx.IsMatch(Trimmed, '^RoundedCorners\s*=', [roIgnoreCase]) then
          AddGeneratedReview(
            'VCL-only streamed property',
            'Generated FMX stream still contains RoundedCorners.',
            'Review the form chrome or visual styling manually in FMX.',
            True);

        if TRegEx.IsMatch(Trimmed, '^TickStyle\s*=', [roIgnoreCase]) then
          AddGeneratedReview(
            'VCL-only streamed property',
            'Generated FMX stream still contains TickStyle.',
            'Remove this VCL property or restyle the FMX trackbar manually.',
            True);

        if TRegEx.IsMatch(Trimmed, '^Layout\s*=\s*tl', [roIgnoreCase]) then
          AddGeneratedReview(
            'Unmapped VCL text-layout property',
            'Generated FMX stream still contains a VCL Layout value.',
            'Map this to an FMX vertical text alignment property such as TextSettings.VertAlign.',
            True);

        if TRegEx.IsMatch(Trimmed, '^object\s+\w+\s*:\s*TTrayIcon\b', [roIgnoreCase]) then
          AddGeneratedReview(
            'Unsupported component still emitted in generated FMX',
            'Generated FMX stream still declares TTrayIcon.',
            'Remove this streamed component and handle tray behavior manually.',
            True);

        if TRegEx.IsMatch(Trimmed, '^object\s+\w+\s*:\s*TApdComPort\b', [roIgnoreCase]) then
          AddGeneratedReview(
            'Unsupported component still emitted in generated FMX',
            'Generated FMX stream still declares TApdComPort.',
            'Remove this streamed component and replace serial communications manually.',
            True);
      end;
    end;

    if MatchText(Ext, ['.pas', '.dpr']) then
    begin
      if (LastSignificantLine <> '') and (not SameText(LastSignificantLine, 'end.')) then
        AddGeneratedReview(
          'Generated Pascal ends unexpectedly',
          'Generated Pascal does not end with end., which usually means the file was truncated or a rewrite left the unit/program incomplete.',
          'Inspect the tail of this generated file, restore the missing closing code, and rerun after correcting the underlying converter rule.',
          True);
    end;
  finally
    Lines.Free;
  end;
end;

procedure TConverterEngine.AuditGeneratedOutput;
var
  Files: TStringDynArray;
  FileName: string;
  FileWriteTime: TDateTime;
begin
  if (FContext = nil) or (FContext.Options.OutputPath = '') or
     (not DirectoryExists(FContext.Options.OutputPath)) then
    Exit;

  Files := TDirectory.GetFiles(FContext.Options.OutputPath, '*.*', TSearchOption.soAllDirectories);
  for FileName in Files do
    if MatchText(LowerCase(ExtractFileExt(FileName)), ['.pas', '.dpr', '.fmx']) then
    begin
      FileWriteTime := TFile.GetLastWriteTime(FileName);

      // Reused output folders can contain stale files from earlier conversions.
      // Only audit files touched during the current run so the report reflects
      // the current project output instead of unrelated leftovers.
      if (FStartTime > 0) and (FileWriteTime < IncSecond(FStartTime, -1)) then
        Continue;

      AuditGeneratedFile(FileName);
    end;
end;

procedure TConverterEngine.ExportMappingPackAuthoringSuggestions;
var
  Issue: TConversionIssue;
  Suggestions: TStringList;
  OutputFile: string;
  Match: TMatch;
  ComponentName: string;
  VclClassName: string;
  FirstItem: Boolean;
  SuggestedClasses: TDictionary<string, Boolean>;

  function JsonEscape(const Value: string): string;
  begin
    Result := StringReplace(Value, '\', '\\', [rfReplaceAll]);
    Result := StringReplace(Result, '"', '\"', [rfReplaceAll]);
    Result := StringReplace(Result, #13#10, '\n', [rfReplaceAll]);
    Result := StringReplace(Result, #13, '\n', [rfReplaceAll]);
    Result := StringReplace(Result, #10, '\n', [rfReplaceAll]);
    Result := StringReplace(Result, #9, '\t', [rfReplaceAll]);
    Result := StringReplace(Result, #0, '\u0000', [rfReplaceAll]);
    Result := StringReplace(Result, #1, '\u0001', [rfReplaceAll]);
    Result := StringReplace(Result, #2, '\u0002', [rfReplaceAll]);
    Result := StringReplace(Result, #3, '\u0003', [rfReplaceAll]);
    Result := StringReplace(Result, #4, '\u0004', [rfReplaceAll]);
    Result := StringReplace(Result, #5, '\u0005', [rfReplaceAll]);
    Result := StringReplace(Result, #6, '\u0006', [rfReplaceAll]);
    Result := StringReplace(Result, #7, '\u0007', [rfReplaceAll]);
    Result := StringReplace(Result, #8, '\u0008', [rfReplaceAll]);
    Result := StringReplace(Result, #11, '\u000B', [rfReplaceAll]);
    Result := StringReplace(Result, #12, '\u000C', [rfReplaceAll]);
    Result := StringReplace(Result, #14, '\u000E', [rfReplaceAll]);
    Result := StringReplace(Result, #15, '\u000F', [rfReplaceAll]);
    Result := StringReplace(Result, #16, '\u0010', [rfReplaceAll]);
    Result := StringReplace(Result, #17, '\u0011', [rfReplaceAll]);
    Result := StringReplace(Result, #18, '\u0012', [rfReplaceAll]);
    Result := StringReplace(Result, #19, '\u0013', [rfReplaceAll]);
    Result := StringReplace(Result, #20, '\u0014', [rfReplaceAll]);
    Result := StringReplace(Result, #21, '\u0015', [rfReplaceAll]);
    Result := StringReplace(Result, #22, '\u0016', [rfReplaceAll]);
    Result := StringReplace(Result, #23, '\u0017', [rfReplaceAll]);
    Result := StringReplace(Result, #24, '\u0018', [rfReplaceAll]);
    Result := StringReplace(Result, #25, '\u0019', [rfReplaceAll]);
    Result := StringReplace(Result, #26, '\u001A', [rfReplaceAll]);
    Result := StringReplace(Result, #27, '\u001B', [rfReplaceAll]);
    Result := StringReplace(Result, #28, '\u001C', [rfReplaceAll]);
    Result := StringReplace(Result, #29, '\u001D', [rfReplaceAll]);
    Result := StringReplace(Result, #30, '\u001E', [rfReplaceAll]);
    Result := StringReplace(Result, #31, '\u001F', [rfReplaceAll]);
  end;

  function IsSuggestionIssue(const AIssue: TConversionIssue): Boolean;
  begin
    Result := SameText(AIssue.ProblemType, 'Mapping assistance') or
      SameText(AIssue.ProblemType, 'Unsupported component') or
      SameText(AIssue.ProblemType, 'Mapping pack detection only') or
      SameText(AIssue.ProblemType, 'Mapping pack manual review') or
      SameText(AIssue.ProblemType, 'Low-confidence mapping pack rule');
  end;
begin
  if (FContext = nil) or (FContext.Options.OutputPath = '') then
    Exit;

  Suggestions := TStringList.Create;
  SuggestedClasses := TDictionary<string, Boolean>.Create(
    TIStringComparer.Ordinal);
  try
    Suggestions.Add('{');
    Suggestions.Add('  "schema": "' + VCL2FMX_MAPPING_PACK_SCHEMA + '",');
    Suggestions.Add('  "pack_name": "Generated_MappingPack_Starter",');
    Suggestions.Add('  "pack_id": "generated.mapping.starter",');
    Suggestions.Add('  "vendor": "User-authored",');
    Suggestions.Add('  "version": "0.1.0",');
    Suggestions.Add('  "description": "Starter pack generated from conversion mapping gaps; review every rule and replace placeholder targets before use.",');
    Suggestions.Add('  "mode": "conservative",');
    Suggestions.Add('  "rules": [');
    FirstItem := True;

    for Issue in FContext.Issues do
    begin
      if not IsSuggestionIssue(Issue) then
        Continue;

      ComponentName := '';
      VclClassName := '';
      Match := TRegEx.Match(Issue.OriginalCode,
        '\bobject\s+([A-Za-z_][A-Za-z0-9_]*)\s*:\s*([A-Za-z_][A-Za-z0-9_]*)',
        [roIgnoreCase]);
      if Match.Success then
      begin
        ComponentName := Match.Groups[1].Value;
        VclClassName := Match.Groups[2].Value;
      end;
      if Trim(VclClassName) = '' then
        Continue;
      if SuggestedClasses.ContainsKey(VclClassName) then
        Continue;
      SuggestedClasses.Add(VclClassName, True);

      if not FirstItem then
        Suggestions.Add('    ,');
      FirstItem := False;
      Suggestions.Add('    {');
      Suggestions.Add('      "vcl_class": "' + JsonEscape(VclClassName) + '",');
      Suggestions.Add('      "fmx_class": "",');
      Suggestions.Add('      "action": "manual_review",');
      Suggestions.Add('      "confidence": 0,');
      Suggestions.Add('      "notes": "' + JsonEscape(Issue.Message) + '",');
      Suggestions.Add('      "manual_review_reason": "' +
        JsonEscape(Issue.SuggestedFix) + '",');
      Suggestions.Add('      "component_name": "' + JsonEscape(ComponentName) + '",');
      Suggestions.Add('      "problem_type": "' + JsonEscape(Issue.ProblemType) + '",');
      Suggestions.Add('      "source_file": "' + JsonEscape(Issue.FileName) + '",');
      Suggestions.Add('      "line": ' + IntToStr(Issue.LineNumber) + ',');
      Suggestions.Add('      "original_code": "' + JsonEscape(Issue.OriginalCode) + '",');
      Suggestions.Add('      "suggested_authoring_action": "' +
        JsonEscape(Issue.SuggestedFix) + '"');
      Suggestions.Add('    }');
    end;

    Suggestions.Add('  ]');
    Suggestions.Add('}');

    if FirstItem then
      Exit;

    OutputFile := TPath.Combine(FContext.Options.OutputPath,
      'MappingPack_Authoring_Suggestions.json');
    TFile.WriteAllText(OutputFile, Suggestions.Text, TEncoding.UTF8);
    FContext.AddIssue(csInfo,
      'Mapping-pack authoring suggestions exported: ' + OutputFile,
      'Mapping-pack authoring suggestions',
      OutputFile,
      'Use this JSON as a starting point when adding reusable component mapping-pack rules. Validate each suggested rule with contracts before trusting it.',
      -1,
      False);
  finally
    SuggestedClasses.Free;
    Suggestions.Free;
  end;
end;
procedure TConverterEngine.BuildCrossUnitSemanticIndex;
var
  Files: TStringDynArray;
  FileName: string;
  Code: string;
  EncodingName: string;
  CleanCode: string;
  Matches: TMatchCollection;
  Match: TMatch;
  SearchOption: TSearchOption;

  function IsExcludedSemanticFile(const AFileName: string): Boolean;
  var
    RelativePath: string;
    SourceRoot: string;
    Parts: TArray<string>;
    PartIndex: Integer;
  begin
    Result := False;
    if (FContext = nil) or (FContext.Options.SourcePath = '') then
      Exit;

    SourceRoot := IncludeTrailingPathDelimiter(TPath.GetFullPath(FContext.Options.SourcePath));
    RelativePath := ExtractRelativePath(SourceRoot, TPath.GetFullPath(AFileName));
    Parts := RelativePath.Split(['\', '/']);
    for PartIndex := 0 to High(Parts) do
      if VCL2FMXIsBuildArtifactFolder(Parts[PartIndex]) then
        Exit(True);
  end;

  procedure AddUnique(AList: TStringList; const AValue: string);
  begin
    if (Trim(AValue) <> '') and (AList.IndexOf(AValue) = -1) then
      AList.Add(AValue);
  end;
begin
  if (FContext = nil) or (FContext.Options.SourcePath = '') or
     (not DirectoryExists(FContext.Options.SourcePath)) then
    Exit;

  FContext.SemanticClassIndex.Clear;
  FContext.SemanticMethodIndex.Clear;
  FContext.SemanticClassIndex.Sorted := True;
  FContext.SemanticClassIndex.Duplicates := dupIgnore;
  FContext.SemanticMethodIndex.Sorted := True;
  FContext.SemanticMethodIndex.Duplicates := dupIgnore;

  if FContext.Options.ProcessSubdirectories then
    SearchOption := TSearchOption.soAllDirectories
  else
    SearchOption := TSearchOption.soTopDirectoryOnly;

  try
    Files := TDirectory.GetFiles(FContext.Options.SourcePath, '*.pas', SearchOption);
  except
    on E: Exception do
    begin
      FContext.AddIssue(csWarning,
        'Cross-unit semantic index could not enumerate Pascal files: ' + E.Message,
        'Pascal semantic index',
        FContext.Options.SourcePath,
        'Verify that the source tree remains accessible and rerun the conversion. The normal file conversion pass may still process accessible files.',
        -1,
        False);
      Exit;
    end;
  end;
  for FileName in Files do
  begin
    if FCancelled then
      Exit;

    if IsExcludedSemanticFile(FileName) then
      Continue;

    if not VCL2FMXTryReadTextFile(FileName, Code, EncodingName) then
      Continue;

    CleanCode := VCL2FMXStripCommentsForAnalysis(Code);

    Matches := TRegEx.Matches(CleanCode,
      '\b([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(class|record|interface|class\s+helper|record\s+helper)\b',
      [roIgnoreCase]);
    for Match in Matches do
    begin
      if FCancelled then
        Exit;
      AddUnique(FContext.SemanticClassIndex, Match.Groups[1].Value);
    end;

    Matches := TRegEx.Matches(CleanCode,
      '\b(?:class\s+procedure|class\s+function|procedure|function|constructor|destructor)\s+([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)\b',
      [roIgnoreCase]);
    for Match in Matches do
    begin
      if FCancelled then
        Exit;
      AddUnique(FContext.SemanticMethodIndex,
        Match.Groups[1].Value + '.' + Match.Groups[2].Value);
    end;
  end;

  FContext.AddIssue(csInfo,
    Format('Cross-unit semantic index built: %d classes, %d methods.',
      [FContext.SemanticClassIndex.Count, FContext.SemanticMethodIndex.Count]),
    'Pascal semantic index',
    '',
    'The converter used this project-wide index to reduce false positives when checking declarations and implementations across units.',
    -1,
    False);
end;
function TConverterEngine.Convert(AContext: TConversionContext): Boolean;
var
  FileName: string;
  TotalFiles: Integer;
  i: Integer;
  HasBlockingIssues: Boolean;
  HasManualReviewIssues: Boolean;
  HasProjectInput: Boolean;
  PreflightIssue: TConversionIssue;
begin
  Result := False;

  FTextReportPath := '';
  FHtmlReportPath := '';
  if not Assigned(AContext) then
    raise EArgumentNilException.Create('Conversion context is not assigned');
  AContext.ClearIssues;
  AContext.CurrentFile := '';
  AContext.LoadedMappingPacks.Clear;
  AContext.MappingPackUsages.Clear;
  RebuildServicesForContext(AContext);
  FCancelled := False;
  FFilesProcessed := 0;
  FFilesConverted := 0;
  FFilesErrors := 0;
  FFilesSkipped := 0;
  FStartTime := Now;
  FEndTime := 0;
  FContext.StartTime := FStartTime;
  FConversionLog.Clear;

  if not Assigned(FLogCallback) then
    LogToFile('WARNING: Log callback not assigned - UI updates disabled')
  else
    UILog(SDisplayScreenMemoConnected);

  UILog('');
  UILog(SDisplayVclToFmxConversionStarted);
  UILog(StringOfChar('=', 40));
  UILog(Format(SDisplaySourceS, [FContext.Options.SourcePath]));
  UILog(Format(SDisplayOutputS, [FContext.Options.OutputPath]));
  UILog('');

  try
  try
    FFileManager.Reset;
    if FContext.HasBlockingIssues then Exit;
    HasProjectInput := FProjectGenerator.ValidateProjectSelection;
    if (FFileManager.FileCount = 0) and not HasProjectInput then
    begin
      FContext.AddIssue(csError, 'No eligible source files were found. Check the source folder and selected file types.');
      Exit;
    end;
    BuildCrossUnitSemanticIndex;

    if not FFileManager.PrepareOutput then
    begin
      Exit;
    end;

    TotalFiles := FFileManager.FileCount;

    UILog(Format(SDisplayFoundDFilesToProcess, [TotalFiles]));
    UILog('');

    i := 0;
    while FFileManager.HasMoreFiles and not FCancelled do
    begin
      FileName := FFileManager.GetNextFile;
      Inc(FFilesProcessed);
      Inc(i);


      UILog(Format(SDisplayDDProcessingS, [i, TotalFiles, ExtractFileName(FileName)]));

      try
        if SameText(ExtractFileExt(FileName), '.pas') then
        begin
          ProcessPasFile(FileName);
        end
        else if SameText(ExtractFileExt(FileName), '.dfm') then
        begin
          ProcessDfmFile(FileName);
        end;
      except
        on E: Exception do
        begin
          Inc(FFilesErrors);
          UILog(Format(SDisplayFailedS, [ExtractFileName(FileName)]),
            Format(SDisplayFailedSS, [ExtractFileName(FileName), E.Message]));
          FContext.AddIssue(csError,
            'File conversion failed: ' + E.Message,
            'File conversion failure',
            '',
            'Open the source file referenced in this report entry, review the exception text, and rerun after correcting the blocker.',
            -1,
            True);
        end;
      end;
    end;

    UILog('');
    if FContext.Options.DryRunPreview then
    begin
      UILog(SDisplayDryRunPreviewConvertedSourceAndProject);
      UILog(SDisplayDryRunPreviewReportsAndMappingSuggestions);
      FContext.AddIssue(csInfo,
        'Dry-run preview skipped converted source and project file generation; reports and mapping suggestions remain enabled.',
        'Dry-run preview',
        '',
        'Review the generated report and any mapping suggestions, then run conversion again with dry-run disabled to write converted source and project artifacts.',
        -1,
        False);
    end
    else
    begin
      UILog(SDisplayGeneratingProjectFiles);

      FProjectGenerator.GenerateProject;
      AuditGeneratedOutput;

      UILog(SDisplayProjectFilesGenerated);
    end;

    ExportMappingPackAuthoringSuggestions;

    FEndTime := Now;
    if FContext.Options.CreateReport then
      GenerateReport;
    HasBlockingIssues := (FFilesErrors > 0) or FContext.HasBlockingIssues;
    HasManualReviewIssues := FContext.HasManualReviewIssues;

    if HasBlockingIssues then
    begin
      UILog(SDisplayConversionCompletedWithBlockingIssuesOpenThe);
      Result := False;
    end
    else if HasManualReviewIssues then
    begin
      UILog(SDisplayConversionCompletedWithManualReviewRequiredOpen);
      Result := True;
    end
    else
    begin
      UILog(SDisplayConversionCompletedCleanlyOpenTheReportFor);
      Result := True;
    end;

  except
    on E: Exception do
    begin
      FEndTime := Now;
      UILog(Format(SDisplayFatalErrorS, [E.Message]));
      FContext.AddIssue(csError,
        'Fatal conversion error: ' + E.Message,
        'Conversion session failed',
        '',
        'Review the fatal error text, correct the blocking condition, and rerun the converter.',
        -1,
        True);
    end;
  end;
  finally
    if FEndTime = 0 then
    begin
      FEndTime := Now;
      for PreflightIssue in FContext.Issues do
        if PreflightIssue.IsBlocking or (PreflightIssue.Severity in [csError, csCritical]) then
          UILog(Format(SDisplayFatalErrorS, [PreflightIssue.Message]));
    end;
  end;
end;

procedure TConverterEngine.CopyPascalIncludeFile(const ASourcePasFile, AIncludePath,
  AIncludeName: string; ALine: Integer);
var
  SourceRoot: string;
  SourceFull: string;
  IncludeFull: string;
  RelativeInclude: string;
  OutputFile: string;
  OutputDir: string;
begin
  if (FContext = nil) or (FContext.Options.OutputPath = '') then
    Exit;

  IncludeFull := TPath.GetFullPath(AIncludePath);
  if not TFile.Exists(IncludeFull) then
    Exit;

  if FContext.Options.SourcePath <> '' then
  begin
    SourceRoot := IncludeTrailingPathDelimiter(TPath.GetFullPath(FContext.Options.SourcePath));
    if not StartsText(SourceRoot, IncludeFull) then
    begin
      FContext.AddIssue(csWarning,
        'Pascal include file was found outside the source folder and was not copied: ' + AIncludeName,
        'Pascal include outside source folder',
        IncludeFull,
        'Copy this include file manually if the generated FMX project still depends on it.',
        ALine,
        False);
      Exit;
    end;
    RelativeInclude := Copy(IncludeFull, Length(SourceRoot) + 1, MaxInt);
  end
  else
  begin
    SourceFull := IncludeTrailingPathDelimiter(TPath.GetFullPath(ExtractFilePath(ASourcePasFile)));
    if StartsText(SourceFull, IncludeFull) then
      RelativeInclude := Copy(IncludeFull, Length(SourceFull) + 1, MaxInt)
    else
      RelativeInclude := TPath.GetFileName(IncludeFull);
  end;

  if (RelativeInclude = '') or TPath.IsPathRooted(RelativeInclude) or
     (Pos('..' + PathDelim, RelativeInclude) > 0) or StartsText('..', RelativeInclude) then
  begin
    FContext.AddIssue(csWarning,
      'Pascal include file could not be safely mapped to the output folder: ' + AIncludeName,
      'Pascal include copy skipped',
      IncludeFull,
      'Copy this include file manually if the generated FMX project still depends on it.',
      ALine,
      False);
    Exit;
  end;

  OutputFile := TPath.Combine(FContext.Options.OutputPath, RelativeInclude);
  OutputDir := ExtractFilePath(OutputFile);
  try
    if (OutputDir <> '') and not DirectoryExists(OutputDir) then
      ForceDirectories(OutputDir);
    TFile.Copy(IncludeFull, OutputFile, True);
    FContext.AddIssue(csInfo,
      'Pascal include file copied to output: ' + RelativeInclude,
      'Pascal include copied',
      IncludeFull,
      'The include directive was preserved and the include file was copied beside the generated output. Review/convert the include contents manually if needed.',
      ALine,
      False);
  except
    on E: Exception do
      FContext.AddIssue(csWarning,
        'Pascal include file could not be copied to output: ' + AIncludeName,
        'Pascal include copy failure',
        IncludeFull,
        'Copy this include file manually. Error: ' + E.Message,
        ALine,
        False);
  end;
end;
procedure TConverterEngine.ScanPascalIncludeDirectives(const AFileName, ACode: string);
const
  MAX_INCLUDE_DEPTH = 16;
var
  IncludeStack: TStringList;

  function CleanIncludeName(const RawName: string): string;
  begin
    Result := Trim(RawName);
    if ((Result.StartsWith('''') and Result.EndsWith('''')) or
        (Result.StartsWith('"') and Result.EndsWith('"'))) and
       (Length(Result) >= 2) then
      Result := Copy(Result, 2, Length(Result) - 2);
    Result := Trim(StringReplace(Result, '/', PathDelim, [rfReplaceAll]));
  end;

  function IsPathUnderSourceRoot(const APath: string): Boolean;
  var
    SourceRoot: string;
    FullPath: string;
  begin
    Result := True;
    if (FContext = nil) or (FContext.Options.SourcePath = '') then
      Exit;

    SourceRoot := IncludeTrailingPathDelimiter(TPath.GetFullPath(FContext.Options.SourcePath));
    FullPath := TPath.GetFullPath(APath);
    Result := StartsText(SourceRoot, FullPath);
  end;

  function ResolveIncludePath(const BaseFile, RawName: string; out ResolvedPath: string): Boolean;
  var
    Candidate: string;
    CleanName: string;
  begin
    Result := False;
    ResolvedPath := '';
    CleanName := CleanIncludeName(RawName);
    if CleanName = '' then
      Exit;

    if TPath.IsPathRooted(CleanName) then
    begin
      Candidate := TPath.GetFullPath(CleanName);
      if TFile.Exists(Candidate) then
      begin
        ResolvedPath := Candidate;
        Exit(True);
      end;
      ResolvedPath := Candidate;
      Exit(False);
    end;

    Candidate := TPath.GetFullPath(TPath.Combine(ExtractFilePath(BaseFile), CleanName));
    if TFile.Exists(Candidate) then
    begin
      ResolvedPath := Candidate;
      Exit(True);
    end;

    if FContext.Options.SourcePath <> '' then
    begin
      Candidate := TPath.GetFullPath(TPath.Combine(FContext.Options.SourcePath, CleanName));
      if TFile.Exists(Candidate) then
      begin
        ResolvedPath := Candidate;
        Exit(True);
      end;
    end;

    ResolvedPath := CleanName;
  end;

  procedure AddIncludeIssue(ASeverity: TConversionSeverity; const AMessage,
    AProblemType, AOriginalCode, ASuggestedFix: string; ALine: Integer;
    AIsBlocking: Boolean);
  begin
    FContext.AddIssue(ASeverity, AMessage, AProblemType, AOriginalCode,
      ASuggestedFix, ALine, AIsBlocking);
  end;

  function StripCommentsForIncludeDirectives(const Code: string): string;
type
  TCommentState = (csNone, csLine, csBrace, csParenStar);
var
  I: Integer;
  State: TCommentState;
  InString: Boolean;
  Ch: Char;

  procedure AppendBlankFor(const AChar: Char);
  begin
    if (AChar = #10) or (AChar = #13) then
      Result := Result + AChar
    else
      Result := Result + ' ';
  end;

  procedure CopyBraceDirective;
  begin
    while I <= Length(Code) do
    begin
      Result := Result + Code[I];
      if Code[I] = '}' then
      begin
        Inc(I);
        Break;
      end;
      Inc(I);
    end;
  end;

  procedure CopyParenStarDirective;
  begin
    while I <= Length(Code) do
    begin
      if (Code[I] = '*') and (I < Length(Code)) and (Code[I + 1] = ')') then
      begin
        Result := Result + '*)';
        Inc(I, 2);
        Break;
      end;
      Result := Result + Code[I];
      Inc(I);
    end;
  end;

begin
  Result := '';
  State := csNone;
  InString := False;
  I := 1;

  while I <= Length(Code) do
  begin
    Ch := Code[I];

    case State of
      csLine:
        begin
          AppendBlankFor(Ch);
          if (Ch = #10) or (Ch = #13) then
            State := csNone;
          Inc(I);
          Continue;
        end;
      csBrace:
        begin
          AppendBlankFor(Ch);
          if Ch = '}' then
            State := csNone;
          Inc(I);
          Continue;
        end;
      csParenStar:
        begin
          if (Ch = '*') and (I < Length(Code)) and (Code[I + 1] = ')') then
          begin
            Result := Result + '  ';
            Inc(I, 2);
            State := csNone;
            Continue;
          end;
          AppendBlankFor(Ch);
          Inc(I);
          Continue;
        end;
    end;

    if InString then
    begin
      Result := Result + Ch;
      if Ch = '''' then
      begin
        if (I < Length(Code)) and (Code[I + 1] = '''') then
        begin
          Result := Result + Code[I + 1];
          Inc(I, 2);
          Continue;
        end;
        InString := False;
      end;
      Inc(I);
      Continue;
    end;

    if Ch = '''' then
    begin
      InString := True;
      Result := Result + Ch;
      Inc(I);
      Continue;
    end;

    if (Ch = '/') and (I < Length(Code)) and (Code[I + 1] = '/') then
    begin
      State := csLine;
      Result := Result + '  ';
      Inc(I, 2);
      Continue;
    end;

    if (Ch = '{') and (I < Length(Code)) and (Code[I + 1] = '$') then
    begin
      CopyBraceDirective;
      Continue;
    end;

    if Ch = '{' then
    begin
      State := csBrace;
      AppendBlankFor(Ch);
      Inc(I);
      Continue;
    end;

    if (Ch = '(') and (I < Length(Code)) and (Code[I + 1] = '*') then
    begin
      if (I + 2 <= Length(Code)) and (Code[I + 2] = '$') then
      begin
        CopyParenStarDirective;
        Continue;
      end;

      State := csParenStar;
      Result := Result + '  ';
      Inc(I, 2);
      Continue;
    end;

    Result := Result + Ch;
    Inc(I);
  end;
end;

  procedure ScanCodeForIncludes(const BaseFile, Code: string; Depth: Integer); forward;

  procedure AnalyzeIncludeFile(const BaseFile, IncludePath, IncludeName,
    DirectiveText: string; DirectiveLine, Depth: Integer);
  var
    FullIncludePath: string;
    IncludeText: string;
    EncodingName: string;
    IncludeLines: TStringList;
    IncludeAnalysisLines: TStringList;
    J: Integer;
    AnalysisLine: string;
    ReportedVCL: Boolean;
    ReportedWinapiMessages: Boolean;
    ReportedMessageHandler: Boolean;
    ReportedMessageAPI: Boolean;
  begin
    FullIncludePath := TPath.GetFullPath(IncludePath);

    if Depth > MAX_INCLUDE_DEPTH then
    begin
      AddIncludeIssue(csWarning,
        'Pascal include nesting depth limit reached: ' + IncludeName,
        'Pascal include depth guard',
        DirectiveText,
        'Review nested include files manually; automatic analysis stops at a safe depth limit.',
        DirectiveLine,
        False);
      Exit;
    end;

    if not IsPathUnderSourceRoot(FullIncludePath) then
    begin
      AddIncludeIssue(csWarning,
        'Pascal include file is outside the source folder and was not analyzed: ' + IncludeName,
        'Pascal include outside source folder',
        FullIncludePath,
        'Move the include under the source tree or review it manually before compiling the generated FMX project.',
        DirectiveLine,
        False);
      Exit;
    end;

    if IncludeStack.IndexOf(AnsiLowerCase(FullIncludePath)) >= 0 then
    begin
      AddIncludeIssue(csWarning,
        'Recursive Pascal include loop detected: ' + IncludeName,
        'Pascal include recursion',
        FullIncludePath,
        'Break the recursive include chain or review it manually; automatic include analysis skipped the recursive edge.',
        DirectiveLine,
        False);
      Exit;
    end;

    CopyPascalIncludeFile(BaseFile, FullIncludePath, IncludeName, DirectiveLine);

    if not VCL2FMXTryReadTextFile(FullIncludePath, IncludeText, EncodingName) then
    begin
      AddIncludeIssue(csWarning,
        'Pascal include file could not be read for analysis: ' + TPath.GetFileName(FullIncludePath),
        'Pascal include read failure',
        FullIncludePath,
        'Open this include file manually and review it for VCL units, message handlers, and Windows-specific code before compiling the generated FMX project.',
        DirectiveLine,
        False);
      Exit;
    end;

    IncludeStack.Add(AnsiLowerCase(FullIncludePath));
    IncludeLines := TStringList.Create;
    IncludeAnalysisLines := TStringList.Create;
    try
      IncludeLines.Text := IncludeText;
      IncludeAnalysisLines.Text := VCL2FMXStripCommentsForAnalysis(IncludeText);
      ReportedVCL := False;
      ReportedWinapiMessages := False;
      ReportedMessageHandler := False;
      ReportedMessageAPI := False;

      for J := 0 to IncludeAnalysisLines.Count - 1 do
      begin
        AnalysisLine := Trim(IncludeAnalysisLines[J]);
        if AnalysisLine = '' then
          Continue;

        if (not ReportedVCL) and
           TRegEx.IsMatch(AnalysisLine, '\bVcl\.', [roIgnoreCase]) then
        begin
          AddIncludeIssue(csManualReview,
            'Included Pascal file contains VCL namespace references: ' + TPath.GetFileName(FullIncludePath),
            'Pascal include VCL reference',
            Format('%s:%d -> %s', [FullIncludePath, J + 1, Trim(IncludeLines[J])]),
            'Manually include/review this file and replace Vcl.* units or types with FMX/System equivalents before compiling the generated project.',
            DirectiveLine,
            True);
          ReportedVCL := True;
        end;

        if (not ReportedWinapiMessages) and
           TRegEx.IsMatch(AnalysisLine, '\bWinapi\.Messages\b|(^|[^A-Za-z0-9_])Messages([^A-Za-z0-9_]|$)', [roIgnoreCase]) then
        begin
          AddIncludeIssue(csWarning,
            'Included Pascal file references Winapi.Messages: ' + TPath.GetFileName(FullIncludePath),
            'Pascal include Winapi.Messages reference',
            Format('%s:%d -> %s', [FullIncludePath, J + 1, Trim(IncludeLines[J])]),
            'Manually review this include file. Windows message units usually require FMX events, System.Messaging, or platform-specific replacement code.',
            DirectiveLine,
            False);
          ReportedWinapiMessages := True;
        end;

        if (not ReportedMessageHandler) and
           TRegEx.IsMatch(AnalysisLine, '^\s*(?:class\s+)?(?:procedure|function)\b.*\bmessage\b.*;', [roIgnoreCase]) then
        begin
          AddIncludeIssue(csManualReview,
            'Included Pascal file declares a VCL message handler: ' + TPath.GetFileName(FullIncludePath),
            'Pascal include message handler',
            Format('%s:%d -> %s', [FullIncludePath, J + 1, Trim(IncludeLines[J])]),
            'Manually include/review this file and replace VCL message handlers with FMX events, System.Messaging, or platform-specific code.',
            DirectiveLine,
            True);
          ReportedMessageHandler := True;
        end;

        if (not ReportedMessageAPI) and
           TRegEx.IsMatch(AnalysisLine, '\b(SendMessage|PostMessage|DispatchMessage|PeekMessage|GetMessage)\s*\(|\.\s*Perform\s*\(|\b(WM_|CM_|CN_|EM_|LB_|CB_|LVM_|TVM_|TCM_|TWM[A-Za-z0-9_]*|TCM[A-Za-z0-9_]*)', [roIgnoreCase]) then
        begin
          AddIncludeIssue(csManualReview,
            'Included Pascal file contains Windows message API usage: ' + TPath.GetFileName(FullIncludePath),
            'Pascal include Windows messaging',
            Format('%s:%d -> %s', [FullIncludePath, J + 1, Trim(IncludeLines[J])]),
            'Manually include/review this file and replace Windows message APIs with FMX control APIs, events, System.Messaging, or platform-specific code.',
            DirectiveLine,
            False);
          ReportedMessageAPI := True;
        end;
      end;

      ScanCodeForIncludes(FullIncludePath, IncludeText, Depth + 1);
    finally
      if IncludeStack.Count > 0 then
        IncludeStack.Delete(IncludeStack.Count - 1);
      IncludeAnalysisLines.Free;
      IncludeLines.Free;
    end;
  end;

  procedure ScanCodeForIncludes(const BaseFile, Code: string; Depth: Integer);
var
  Lines: TStringList;
  OriginalLines: TStringList;
  I: Integer;
  Match: TMatch;
  IncludeName: string;
  IncludePath: string;
  OriginalLine: string;
begin
  Lines := TStringList.Create;
  OriginalLines := TStringList.Create;
  try
    OriginalLines.Text := Code;
    Lines.Text := StripCommentsForIncludeDirectives(Code);
    for I := 0 to Lines.Count - 1 do
    begin
      Match := TRegEx.Match(Lines[I],
        '\{\$\s*(?:I|INCLUDE)\s+([^}]+)\}|\(\*\$\s*(?:I|INCLUDE)\s+(.+?)\*\)',
        [roIgnoreCase]);
      while Match.Success do
      begin
        IncludeName := Match.Groups[1].Value;
        if IncludeName = '' then
          IncludeName := Match.Groups[2].Value;
        IncludeName := CleanIncludeName(IncludeName);
        if I < OriginalLines.Count then
          OriginalLine := Trim(OriginalLines[I])
        else
          OriginalLine := Trim(Lines[I]);

        AddIncludeIssue(csWarning,
          'Pascal include directive found: ' + IncludeName,
          'Pascal include directive',
          OriginalLine,
          'The converter analyzes {$I}/{$INCLUDE} files, preserves the directive, and copies source-tree include files to the generated output. It does not inline include text by default.',
          I + 1,
          False);

        if not ResolveIncludePath(BaseFile, IncludeName, IncludePath) then
        begin
          AddIncludeIssue(csWarning,
            'Pascal include file could not be found for analysis: ' + IncludeName,
            'Pascal include file missing',
            OriginalLine,
            'Locate this include file manually and review it for VCL units, message handlers, and Windows-specific code before compiling the generated FMX project.',
            I + 1,
            False);
          Match := Match.NextMatch;
          Continue;
        end;

        AnalyzeIncludeFile(BaseFile, IncludePath, IncludeName, OriginalLine, I + 1, Depth);
        Match := Match.NextMatch;
      end;
    end;
  finally
    OriginalLines.Free;
    Lines.Free;
  end;
end;

begin
  IncludeStack := TStringList.Create;
  try
    IncludeStack.CaseSensitive := False;
    IncludeStack.Add(AnsiLowerCase(TPath.GetFullPath(AFileName)));
    ScanCodeForIncludes(AFileName, ACode, 1);
  finally
    IncludeStack.Free;
  end;
end;
procedure TConverterEngine.ProcessPasFile(const AFileName: string);
var
  Code: string;
  OriginalCode: string;
  ConvertedOK: Boolean;

  function LastSignificantPascalLine(const ACode: string): string;
  var
    Lines: TStringList;
    I: Integer;
    S: string;
  begin
    Result := '';
    Lines := TStringList.Create;
    try
      Lines.Text := ACode;
      for I := Lines.Count - 1 downto 0 do
      begin
        S := Trim(TRegEx.Replace(Lines[I], '//.*$', ''));
        if S = '' then
          Continue;
        if StartsText('{', S) or StartsText('(*', S) then
          Continue;
        Result := S;
        Break;
      end;
    finally
      Lines.Free;
    end;
  end;

  procedure RestoreFinalEndDotIfLost;
  var
    SourceTail: string;
    ConvertedTail: string;
  begin
    SourceTail := LastSignificantPascalLine(OriginalCode);
    ConvertedTail := LastSignificantPascalLine(Code);
    if SameText(SourceTail, 'end.') and
       (ConvertedTail <> '') and
       (not SameText(ConvertedTail, 'end.')) then
    begin
      Code := TrimRight(Code) + sLineBreak + 'end.' + sLineBreak;
      FContext.AddIssue(csWarning,
        'Generated Pascal final end. was restored for ' + ExtractFileName(AFileName),
        'Pascal structure safeguard',
        ConvertedTail,
        'The source unit ended with end. but the converted unit did not. The converter restored the final terminator; review the tail of this generated file in the IDE.',
        -1,
        False);
    end;
  end;
begin
  UILog(Format(SDisplayProcessingPascalFileS, [ExtractFileName(AFileName)]),
    Format(SDisplayProcessingPascalS, [ExtractFileName(AFileName)]));
  ConvertedOK := False;
  FContext.CurrentFile := AFileName;

  if not TryReadWithEncoding(AFileName, Code) then
  begin
    Inc(FFilesSkipped);
    Inc(FFilesErrors);
    FContext.AddIssue(csError,
      'Pascal source could not be read: ' + ExtractFileName(AFileName),
      'Pascal source read failure', '',
      'Ensure the source file is accessible and not locked, then rerun the conversion.',
      -1, True);
    UILog(SDisplayFailedCouldNotReadFile);
    Exit;
  end;
  OriginalCode := Code;
  ScanPascalIncludeDirectives(AFileName, OriginalCode);

  try
    FOrchestrator.ConvertPascal(AFileName, Code);
    RestoreFinalEndDotIfLost;
    Inc(FFilesConverted);
    ConvertedOK := True;
    UILog(SDisplayConverted);
  except
    on E: Exception do
    begin
      Inc(FFilesErrors);
      UILog(SDisplayFailed, Format(SDisplayFailedS, [E.Message]));
      FContext.AddIssue(csError,
        'Pascal conversion could not complete: ' + E.Message,
        'Pascal conversion failure',
        '',
        'Open the Pascal unit in the IDE, inspect the failing construct, and rerun after correcting the blocker.',
        -1,
        True);
    end;
  end;

  if ConvertedOK then
  begin
    if not FFileManager.SaveConvertedFile(AFileName, Code) then
    begin
      Inc(FFilesErrors);
      UILog(SDisplayFailedConvertedPascalFileWasNotSaved);
    end;
  end
  else
  begin
    UILog(SDisplaySkippedSavePascalConversionDidNotProduce);
    FContext.AddIssue(csError,
      'Pascal file was not saved because conversion did not complete safely: ' +
        ExtractFileName(AFileName),
      'Pascal save skipped',
      '',
      'Review the earlier conversion issue for this file before using any generated output.',
      -1,
      True);
  end;
end;

procedure TConverterEngine.AuditDfmFmxFidelity(const AFileName, ASourceDfm,
  AGeneratedFmx: string);
var
  SourceLines: TStringList;
  I: Integer;
  Match: TMatch;
  EventName: string;
  HandlerName: string;
  ExpectedAssignment: string;
  CurrentObjectName: string;
  CurrentObjectClass: string;
  PropName: string;
  PropValue: string;

  function DfmTextLiteralToVisibleText(const AValue: string): string;
  var
    P: Integer;
    CodeStart: Integer;
    CodeText: string;
    CodeValue: Integer;
  begin
    Result := '';
    P := 1;
    while P <= Length(AValue) do
    begin
      if AValue[P] = '''' then
      begin
        Inc(P);
        while P <= Length(AValue) do
        begin
          if AValue[P] = '''' then
          begin
            if (P < Length(AValue)) and (AValue[P + 1] = '''') then
            begin
              Result := Result + '''';
              Inc(P, 2);
              Continue;
            end;
            Inc(P);
            Break;
          end;

          Result := Result + AValue[P];
          Inc(P);
        end;
      end
      else if AValue[P] = '#' then
      begin
        Inc(P);
        CodeStart := P;
        while (P <= Length(AValue)) and CharInSet(AValue[P], ['0'..'9']) do
          Inc(P);
        CodeText := Copy(AValue, CodeStart, P - CodeStart);
        if TryStrToInt(CodeText, CodeValue) then
          Result := Result + Char(CodeValue);
      end
      else
        Inc(P);
    end;
  end;

  function GeneratedContainsPropertyValue(const AGeneratedFmx, APropName,
    APropValue: string): Boolean;
  var
    VisibleValue: string;
    TrimmedVisibleValue: string;
  begin
    Result := ContainsText(AGeneratedFmx, APropValue);
    if Result then
      Exit;

    VisibleValue := DfmTextLiteralToVisibleText(APropValue);
    TrimmedVisibleValue := Trim(VisibleValue);
    if TrimmedVisibleValue = '' then
      Exit(False);

    Result :=
      ContainsText(AGeneratedFmx, APropName + ' = ' + QuotedStr(TrimmedVisibleValue)) or
      ContainsText(AGeneratedFmx, 'Text = ' + QuotedStr(TrimmedVisibleValue)) or
      ContainsText(AGeneratedFmx, 'Caption = ' + QuotedStr(TrimmedVisibleValue)) or
      ((Length(TrimmedVisibleValue) >= 4) and ContainsText(AGeneratedFmx, TrimmedVisibleValue));
  end;

  function IsUsefulPropertyValue(const AObjectName, APropName,
    APropValue: string): Boolean;
  var
    CleanValue: string;
  begin
    CleanValue := Trim(APropValue);
    if CleanValue = '' then
      Exit(False);
    if SameText(APropName, 'Caption') and
       SameText(CleanValue, QuotedStr(AObjectName)) then
      Exit(False);
    Result := True;
  end;
begin
  if Trim(ASourceDfm) = '' then
    Exit;

  SourceLines := TStringList.Create;
  try
    SourceLines.Text := ASourceDfm;
    CurrentObjectName := '';
    CurrentObjectClass := '';

    for I := 0 to SourceLines.Count - 1 do
    begin
      Match := TRegEx.Match(SourceLines[I],
        '^\s*(?:object|inherited|inline)\s+([A-Za-z_][A-Za-z0-9_]*)\s*:\s*([A-Za-z_][A-Za-z0-9_]*)',
        [roIgnoreCase]);
      if Match.Success then
      begin
        CurrentObjectName := Match.Groups[1].Value;
        CurrentObjectClass := Match.Groups[2].Value;
        if not ContainsText(AGeneratedFmx, CurrentObjectName) then
          FContext.AddIssue(csWarning,
            Format('DFM/FMXL fidelity check: source object %s (%s) was not found by name in the generated FMX.',
              [CurrentObjectName, CurrentObjectClass]),
            'DFM/FMXL object fidelity check',
            Trim(SourceLines[I]),
            'Review the generated form. If this object was intentionally redesigned or folded into another FMX control, no action is needed; otherwise add or refine the component mapping rule.',
            I + 1,
            False);
        Continue;
      end;

      Match := TRegEx.Match(SourceLines[I],
        '^\s*(Caption|Text)\s*=\s*(.+?)\s*$', [roIgnoreCase]);
      if Match.Success and (CurrentObjectName <> '') then
      begin
        PropName := Match.Groups[1].Value;
        PropValue := Match.Groups[2].Value;
        if IsUsefulPropertyValue(CurrentObjectName, PropName, PropValue) and
           (not GeneratedContainsPropertyValue(AGeneratedFmx, PropName, PropValue)) then
          FContext.AddIssue(csWarning,
            Format('DFM/FMXL property fidelity check: %s.%s value %s was not found in the generated FMX.',
              [CurrentObjectName, PropName, PropValue]),
            'DFM/FMXL property fidelity check',
            Trim(SourceLines[I]),
            'Review the generated form. If the text/caption still matters visually or at runtime, map it to the appropriate FMX property or child text control.',
            I + 1,
            False);
        Continue;
      end;

      Match := TRegEx.Match(SourceLines[I],
        '^\s*(On[A-Za-z0-9_]+)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$',
        [roIgnoreCase]);
      if not Match.Success then
        Continue;

      EventName := Match.Groups[1].Value;
      HandlerName := Match.Groups[2].Value;
      ExpectedAssignment := EventName + ' = ' + HandlerName;

      if (Pos(ExpectedAssignment, AGeneratedFmx) = 0) and
         (not ContainsText(AGeneratedFmx, HandlerName)) then
        FContext.AddIssue(csWarning,
          Format('DFM/FMXL fidelity check: event handler %s.%s was present in the source DFM but was not emitted in the generated FMX.',
            [ExtractFileName(AFileName), ExpectedAssignment]),
          'DFM/FMXL fidelity check',
          Trim(SourceLines[I]),
          'Reconnect this event manually in the FMX designer or add a converter rule if this event is reusable across projects.',
          I + 1,
          False);
    end;
  finally
    SourceLines.Free;
  end;
end;
procedure TConverterEngine.ProcessDfmFile(const AFileName: string);
var
  Code: string;
  SourceDfm: string;
  EncodingName: string;
  ConvertedOK: Boolean;
begin
  UILog(Format(SDisplayProcessingDfmFileS, [ExtractFileName(AFileName)]),
    Format(SDisplayProcessingDfmS, [ExtractFileName(AFileName)]));
  ConvertedOK := False;
  SourceDfm := '';
  EncodingName := '';
  FContext.CurrentFile := AFileName;

  if TFile.Exists(AFileName) and
     (TFile.GetSize(AFileName) > VCL2FMX_MAX_TEXT_DFM_BYTES) then
  begin
    Inc(FFilesSkipped);
    Inc(FFilesErrors);
    UILog(SDisplayFailedDfmFileIsTooLargeFor);
    FContext.AddIssue(csError,
      'DFM file is too large for safe automatic parsing: ' +
        ExtractFileName(AFileName),
      'DFM size guard',
      '',
      'Open this DFM in Delphi and split or simplify the form before reconverting.',
      -1,
      True);
    Exit;
  end;

  Code := '';
  if not VCL2FMXTryReadTextFile(AFileName, SourceDfm, EncodingName) then
  begin
    Inc(FFilesSkipped);
    Inc(FFilesErrors);
    UILog(SDisplayFailedUnableToReadDfmSourceText);
    FContext.AddIssue(csError,
      'DFM source could not be read with a supported encoding: ' +
        ExtractFileName(AFileName),
      'DFM source read failure',
      '',
      'Save the DFM as text or UTF-8 in Delphi and rerun the conversion.',
      -1,
      True);
    Exit;
  end;
  UILog(SDisplayDetectingDfmStreamFormat);
  try
    FOrchestrator.ConvertDFM(AFileName, Code);
    if Trim(Code) = '' then
      raise EConvertError.Create('DFM conversion returned empty output');
    AuditDfmFmxFidelity(AFileName, SourceDfm, Code);
    Inc(FFilesConverted);
    ConvertedOK := True;
    UILog(SDisplayConverted);
  except
    on E: Exception do
    begin
      Inc(FFilesSkipped);
      Inc(FFilesErrors);
      UILog(SDisplayFailed, Format(SDisplayFailedS, [E.Message]));
      FContext.AddIssue(csError,
        'DFM conversion could not complete: ' + E.Message,
        'DFM conversion failure',
        '',
        'Open the source DFM, inspect the failing object or property, and rerun after correcting the blocker.',
        -1,
        True);
    end;
  end;

  if ConvertedOK then
  begin
    if not FFileManager.SaveConvertedFile(AFileName, Code) then
    begin
      Inc(FFilesErrors);
      UILog(SDisplayFailedConvertedDfmFileWasNotSaved);
    end;
  end
  else
  begin
    UILog(SDisplaySkippedSaveDfmConversionDidNotProduce);
    FContext.AddIssue(csError,
      'DFM file was not saved because conversion did not complete safely: ' +
        ExtractFileName(AFileName),
      'DFM save skipped',
      '',
      'Review the earlier DFM conversion issue for this file before using any generated output.',
      -1,
      True);
  end;
end;

procedure TConverterEngine.AddHtmlReportDocumentHead(const AHtml: TStrings);
begin
  AHtml.Add('<!DOCTYPE html>');
  AHtml.Add('<html lang="en">');
  AHtml.Add('<head>');
  AHtml.Add('  <meta charset="utf-8">');
  AHtml.Add('  <meta name="viewport" content="width=device-width, initial-scale=1.0">');
  AHtml.Add('  <title>VCL to FMX Conversion Report</title>');
  AHtml.Add('  <style>');
  AHtml.Add('    :root {');
  AHtml.Add('      color-scheme: light;');
  AHtml.Add('      --page-bg: #eef5fd;');
  AHtml.Add('      --card-bg: #ffffff;');
  AHtml.Add('      --hero-a: #2f6fcd;');
  AHtml.Add('      --hero-b: #5d95e2;');
  AHtml.Add('      --text: #13314f;');
  AHtml.Add('      --muted: #58708d;');
  AHtml.Add('      --line: #d6e4f3;');
  AHtml.Add('      --info: #2f6fcd;');
  AHtml.Add('      --warning: #c98a19;');
  AHtml.Add('      --manual: #b25f2c;');
  AHtml.Add('      --error: #c24141;');
  AHtml.Add('    }');
  AHtml.Add('    * { box-sizing: border-box; }');
  AHtml.Add('    body {');
  AHtml.Add('      margin: 0;');
  AHtml.Add('      padding: 24px;');
  AHtml.Add('      font-family: "Segoe UI", Tahoma, sans-serif;');
  AHtml.Add('      color: var(--text);');
  AHtml.Add('      background: linear-gradient(180deg, #f6faff 0%, var(--page-bg) 100%);');
  AHtml.Add('    }');
  AHtml.Add('    .page {');
  AHtml.Add('      max-width: 1180px;');
  AHtml.Add('      margin: 0 auto;');
  AHtml.Add('    }');
  AHtml.Add('    .hero {');
  AHtml.Add('      border-radius: 24px;');
  AHtml.Add('      padding: 28px 32px;');
  AHtml.Add('      color: #ffffff;');
  AHtml.Add('      background: linear-gradient(135deg, var(--hero-a) 0%, var(--hero-b) 100%);');
  AHtml.Add('      box-shadow: 0 20px 40px rgba(30, 72, 123, 0.15);');
  AHtml.Add('    }');
  AHtml.Add('    .eyebrow {');
  AHtml.Add('      font-size: 12px;');
  AHtml.Add('      text-transform: uppercase;');
  AHtml.Add('      letter-spacing: 0.12em;');
  AHtml.Add('      opacity: 0.8;');
  AHtml.Add('    }');
  AHtml.Add('    h1 {');
  AHtml.Add('      margin: 10px 0 8px;');
  AHtml.Add('      font-size: 34px;');
  AHtml.Add('      line-height: 1.15;');
  AHtml.Add('    }');
  AHtml.Add('    .hero p {');
  AHtml.Add('      margin: 0;');
  AHtml.Add('      max-width: 900px;');
  AHtml.Add('      color: rgba(255,255,255,0.92);');
  AHtml.Add('    }');
  AHtml.Add('    .status-chip {');
  AHtml.Add('      display: inline-block;');
  AHtml.Add('      margin-top: 18px;');
  AHtml.Add('      padding: 8px 14px;');
  AHtml.Add('      border-radius: 999px;');
  AHtml.Add('      background: rgba(255,255,255,0.18);');
  AHtml.Add('      font-weight: 600;');
  AHtml.Add('    }');
  AHtml.Add('    .meta {');
  AHtml.Add('      display: grid;');
  AHtml.Add('      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));');
  AHtml.Add('      gap: 14px;');
  AHtml.Add('      margin-top: 16px;');
  AHtml.Add('    }');
  AHtml.Add('    .meta-card, .section, .manual-card {');
  AHtml.Add('      background: var(--card-bg);');
  AHtml.Add('      border: 1px solid var(--line);');
  AHtml.Add('      border-radius: 20px;');
  AHtml.Add('      box-shadow: 0 12px 28px rgba(17, 49, 79, 0.06);');
  AHtml.Add('    }');
  AHtml.Add('    .meta-card {');
  AHtml.Add('      padding: 16px 18px;');
  AHtml.Add('    }');
  AHtml.Add('    .meta-card .label {');
  AHtml.Add('      font-size: 12px;');
  AHtml.Add('      color: var(--muted);');
  AHtml.Add('      text-transform: uppercase;');
  AHtml.Add('      letter-spacing: 0.08em;');
  AHtml.Add('    }');
  AHtml.Add('    .meta-card .value {');
  AHtml.Add('      margin-top: 8px;');
  AHtml.Add('      font-size: 25px;');
  AHtml.Add('      font-weight: 700;');
  AHtml.Add('    }');
  AHtml.Add('    .section {');
  AHtml.Add('      margin-top: 16px;');
  AHtml.Add('      padding: 18px 22px;');
  AHtml.Add('    }');
  AHtml.Add('    .section h2 {');
  AHtml.Add('      margin: 0 0 8px;');
  AHtml.Add('      font-size: 22px;');
  AHtml.Add('    }');
  AHtml.Add('    .section p.section-note {');
  AHtml.Add('      margin: 0 0 14px;');
  AHtml.Add('      color: var(--muted);');
  AHtml.Add('    }');
  AHtml.Add('    details.disclosure > summary {');
  AHtml.Add('      cursor: pointer;');
  AHtml.Add('      list-style: none;');
  AHtml.Add('      display: flex;');
  AHtml.Add('      align-items: baseline;');
  AHtml.Add('      justify-content: space-between;');
  AHtml.Add('      gap: 12px;');
  AHtml.Add('    }');
  AHtml.Add('    details.disclosure > summary::-webkit-details-marker { display: none; }');
  AHtml.Add('    details.disclosure > summary h2 { margin: 0; }');
  AHtml.Add('    details.disclosure > summary span { color: var(--muted); font-size: 13px; font-weight: 600; }');
  AHtml.Add('    details.disclosure[open] > summary { margin-bottom: 14px; }');
  AHtml.Add('    table {');
  AHtml.Add('      width: 100%;');
  AHtml.Add('      border-collapse: collapse;');
  AHtml.Add('    }');
  AHtml.Add('    th, td {');
  AHtml.Add('      padding: 12px 10px;');
  AHtml.Add('      text-align: left;');
  AHtml.Add('      vertical-align: top;');
  AHtml.Add('      border-top: 1px solid var(--line);');
  AHtml.Add('      font-size: 14px;');
  AHtml.Add('      overflow-wrap: anywhere;');
  AHtml.Add('    }');
  AHtml.Add('    th.row-index {');
  AHtml.Add('      width: 42px;');
  AHtml.Add('      min-width: 42px;');
  AHtml.Add('      white-space: nowrap;');
  AHtml.Add('      text-align: right;');
  AHtml.Add('      overflow-wrap: normal;');
  AHtml.Add('      word-break: normal;');
  AHtml.Add('    }');
  AHtml.Add('    th {');
  AHtml.Add('      font-size: 12px;');
  AHtml.Add('      text-transform: uppercase;');
  AHtml.Add('      letter-spacing: 0.08em;');
  AHtml.Add('      color: var(--muted);');
  AHtml.Add('      border-top: none;');
  AHtml.Add('      padding-top: 0;');
  AHtml.Add('    }');
  AHtml.Add('    .severity {');
  AHtml.Add('      display: inline-block;');
  AHtml.Add('      min-width: 76px;');
  AHtml.Add('      padding: 5px 10px;');
  AHtml.Add('      border-radius: 999px;');
  AHtml.Add('      font-size: 11px;');
  AHtml.Add('      font-weight: 700;');
  AHtml.Add('      color: #ffffff;');
  AHtml.Add('      text-align: center;');
  AHtml.Add('      white-space: nowrap;');
  AHtml.Add('    }');
  AHtml.Add('    .issues-table th:first-child, .issues-table td:first-child {');
  AHtml.Add('      width: 100px;');
  AHtml.Add('      min-width: 100px;');
  AHtml.Add('    }');
  AHtml.Add('    .severity.info { background: var(--info); }');
  AHtml.Add('    .severity.warning { background: var(--warning); }');
  AHtml.Add('    .severity.manual { background: var(--manual); }');
  AHtml.Add('    .severity.error { background: var(--error); }');
  AHtml.Add('    .severity.neutral { background: #7a8ea7; }');
  AHtml.Add('    .issue-list {');
  AHtml.Add('      display: grid;');
  AHtml.Add('      gap: 10px;');
  AHtml.Add('    }');
  AHtml.Add('    .issue-card {');
  AHtml.Add('      border-top: 1px solid var(--line);');
  AHtml.Add('      padding: 12px 0 10px;');
  AHtml.Add('    }');
  AHtml.Add('    .issue-card:first-child { border-top: none; padding-top: 0; }');
  AHtml.Add('    .issue-card-header {');
  AHtml.Add('      display: flex;');
  AHtml.Add('      flex-wrap: wrap;');
  AHtml.Add('      gap: 10px;');
  AHtml.Add('      align-items: center;');
  AHtml.Add('      margin-bottom: 8px;');
  AHtml.Add('    }');
  AHtml.Add('    .issue-card-header strong { font-size: 14px; }');
  AHtml.Add('    .issue-card-header span.meta { color: var(--muted); font-size: 12px; font-weight: 600; }');
  AHtml.Add('    .issue-message { line-height: 1.35; max-width: 920px; }');
  AHtml.Add('    .issue-path {');
  AHtml.Add('      margin-top: 8px;');
  AHtml.Add('      color: var(--muted);');
  AHtml.Add('      font-family: "Consolas", "Courier New", monospace;');
  AHtml.Add('      font-size: 12px;');
  AHtml.Add('      overflow-wrap: anywhere;');
  AHtml.Add('    }');
  AHtml.Add('    .issue-fix { margin-top: 8px; color: var(--muted); line-height: 1.35; }');
  AHtml.Add('    .manual-list {');
  AHtml.Add('      display: grid;');
  AHtml.Add('      gap: 12px;');
  AHtml.Add('    }');
  AHtml.Add('    .manual-card {');
  AHtml.Add('      padding: 14px 18px;');
  AHtml.Add('    }');
  AHtml.Add('    .manual-card h3 {');
  AHtml.Add('      margin: 0 0 10px;');
  AHtml.Add('      font-size: 18px;');
  AHtml.Add('    }');
  AHtml.Add('    .usage-list {');
  AHtml.Add('      display: grid;');
  AHtml.Add('      gap: 12px;');
  AHtml.Add('    }');
  AHtml.Add('    .usage-card {');
  AHtml.Add('      border-top: 1px solid var(--line);');
  AHtml.Add('      padding: 14px 0 16px;');
  AHtml.Add('    }');
  AHtml.Add('    .usage-card:first-child { border-top: none; padding-top: 0; }');
  AHtml.Add('    .usage-title {');
  AHtml.Add('      display: flex;');
  AHtml.Add('      flex-wrap: wrap;');
  AHtml.Add('      gap: 10px;');
  AHtml.Add('      align-items: baseline;');
  AHtml.Add('      justify-content: space-between;');
  AHtml.Add('      font-weight: 700;');
  AHtml.Add('      font-size: 15px;');
  AHtml.Add('    }');
  AHtml.Add('    .usage-title span {');
  AHtml.Add('      color: var(--muted);');
  AHtml.Add('      font-size: 13px;');
  AHtml.Add('      font-weight: 600;');
  AHtml.Add('    }');
  AHtml.Add('    .usage-map {');
  AHtml.Add('      margin-top: 6px;');
  AHtml.Add('      font-family: "Consolas", "Courier New", monospace;');
  AHtml.Add('      font-size: 13px;');
  AHtml.Add('    }');
  AHtml.Add('    .usage-meta {');
  AHtml.Add('      display: flex;');
  AHtml.Add('      flex-wrap: wrap;');
  AHtml.Add('      gap: 12px;');
  AHtml.Add('      margin-top: 8px;');
  AHtml.Add('      color: var(--muted);');
  AHtml.Add('      font-size: 13px;');
  AHtml.Add('    }');
  AHtml.Add('    .usage-path {');
  AHtml.Add('      margin-top: 10px;');
  AHtml.Add('      padding: 9px 10px;');
  AHtml.Add('      border-radius: 8px;');
  AHtml.Add('      background: #f7fbff;');
  AHtml.Add('      border: 1px solid #e4eef8;');
  AHtml.Add('      font-family: "Consolas", "Courier New", monospace;');
  AHtml.Add('      font-size: 12px;');
  AHtml.Add('      overflow-wrap: anywhere;');
  AHtml.Add('    }');
  AHtml.Add('    .usage-notes {');
  AHtml.Add('      margin-top: 10px;');
  AHtml.Add('      color: var(--muted);');
  AHtml.Add('      line-height: 1.35;');
  AHtml.Add('    }');
  AHtml.Add('    .compact-list {');
  AHtml.Add('      display: grid;');
  AHtml.Add('      gap: 8px;');
  AHtml.Add('      font-family: "Consolas", "Courier New", monospace;');
  AHtml.Add('      font-size: 13px;');
  AHtml.Add('    }');
  AHtml.Add('    .compact-list div {');
  AHtml.Add('      padding-top: 8px;');
  AHtml.Add('      border-top: 1px solid var(--line);');
  AHtml.Add('      overflow-wrap: anywhere;');
  AHtml.Add('    }');
  AHtml.Add('    .compact-list div:first-child { border-top: none; padding-top: 0; }');
  AHtml.Add('    .mapping-pack-list {');
  AHtml.Add('      border-top: 1px solid var(--line);');
  AHtml.Add('    }');
  AHtml.Add('    .mapping-pack-row {');
  AHtml.Add('      display: grid;');
  AHtml.Add('      grid-template-columns: 48px minmax(0, 1fr);');
  AHtml.Add('      column-gap: 12px;');
  AHtml.Add('      align-items: start;');
  AHtml.Add('      padding: 12px 0;');
  AHtml.Add('      border-bottom: 1px solid var(--line);');
  AHtml.Add('    }');
  AHtml.Add('    .mapping-pack-index {');
  AHtml.Add('      color: var(--muted);');
  AHtml.Add('      font-weight: 700;');
  AHtml.Add('      text-align: right;');
  AHtml.Add('      white-space: nowrap;');
  AHtml.Add('      overflow-wrap: normal;');
  AHtml.Add('      word-break: keep-all;');
  AHtml.Add('      font-variant-numeric: tabular-nums;');
  AHtml.Add('    }');
  AHtml.Add('    .mapping-pack-text {');
  AHtml.Add('      min-width: 0;');
  AHtml.Add('      overflow-wrap: anywhere;');
  AHtml.Add('    }');
  AHtml.Add('    .empty-state {');
  AHtml.Add('      color: var(--muted);');
  AHtml.Add('      padding: 8px 0;');
  AHtml.Add('    }');
  AHtml.Add('    .manual-meta {');
  AHtml.Add('      display: flex;');
  AHtml.Add('      flex-wrap: wrap;');
  AHtml.Add('      gap: 10px;');
  AHtml.Add('      margin-bottom: 12px;');
  AHtml.Add('      color: var(--muted);');
  AHtml.Add('      font-size: 13px;');
  AHtml.Add('    }');
  AHtml.Add('    .block {');
  AHtml.Add('      margin-top: 10px;');
  AHtml.Add('      padding: 10px 12px;');
  AHtml.Add('      border-radius: 14px;');
  AHtml.Add('      background: #f7fbff;');
  AHtml.Add('      border: 1px solid #e4eef8;');
  AHtml.Add('    }');
  AHtml.Add('    .block-label {');
  AHtml.Add('      margin-bottom: 6px;');
  AHtml.Add('      font-size: 12px;');
  AHtml.Add('      font-weight: 700;');
  AHtml.Add('      text-transform: uppercase;');
  AHtml.Add('      letter-spacing: 0.08em;');
  AHtml.Add('      color: var(--muted);');
  AHtml.Add('    }');
  AHtml.Add('    .pre {');
  AHtml.Add('      white-space: pre-wrap;');
  AHtml.Add('      font-family: "Consolas", "Courier New", monospace;');
  AHtml.Add('      font-size: 13px;');
  AHtml.Add('      line-height: 1.35;');
  AHtml.Add('    }');
  AHtml.Add('    details.block {');
  AHtml.Add('      padding: 0;');
  AHtml.Add('      overflow: hidden;');
  AHtml.Add('    }');
  AHtml.Add('    details.block > summary.block-label {');
  AHtml.Add('      margin-bottom: 0;');
  AHtml.Add('      padding: 10px 12px;');
  AHtml.Add('      cursor: pointer;');
  AHtml.Add('    }');
  AHtml.Add('    details.block[open] > summary.block-label { border-bottom: 1px solid #e4eef8; }');
  AHtml.Add('    details.block > .pre { padding: 10px 12px; }');
  AHtml.Add('    .log-block { max-height: 420px; overflow: auto; }');
  AHtml.Add('    .footer-note {');
  AHtml.Add('      margin-top: 20px;');
  AHtml.Add('      color: var(--muted);');
  AHtml.Add('      font-size: 13px;');
  AHtml.Add('    }');
  AHtml.Add('    @media print {');
  AHtml.Add('      body { background: #ffffff; padding: 0; }');
  AHtml.Add('      .page { max-width: none; }');
  AHtml.Add('      .hero, .meta-card, .section, .manual-card { box-shadow: none; }');
  AHtml.Add('      .section, .manual-card, .meta-card { break-inside: avoid; }');
  AHtml.Add('    }');
  AHtml.Add('  </style>');
  AHtml.Add('</head>');
end;

procedure TConverterEngine.GenerateReport;
var
  Report: TStringList;
  Html: TStringList;
  Issue: TConversionIssue;
  InfoCount, WarnCount, ManualCount, ManualIssueCount, ErrorCount,
    BlockingCount: Integer;
  DryRunPreviewCount: Integer;
  Duration: TDateTime;
  Secs: Integer;
  RunTimeText: string;
  ManualIndex: Integer;
  StatusText: string;
  NextStepText: string;
  SeenBlockingKeys: TStringList;
  ManualGroups: TStringList;
  AffectedFiles: TStringList;
  VisibleIssueCount: Integer;
  HasBlockingOutcome: Boolean;
  IssueIndex: Integer;
  ReportModel: TConversionReportModel;
  ProtectedValues: TArray<string>;
  ProtectedData: TStringList;
  ReportLine: Integer;

  function TranslateReportPresentation(const Source: string; const IsHtml: Boolean): string;
  var
    Value, Token: string;
    Index: Integer;
  begin
    Result := Source;
    // Protect data before translating presentation; JSON and the report model stay unchanged.
    for Index := 0 to High(ProtectedValues) do
    begin
      Value := ProtectedValues[Index];
      if (Length(Value) < 3) or not TRegEx.IsMatch(Value, '[A-Za-z\x{0080}-\x{FFFF}]') then Continue;
      if IsHtml then Value := TNetEncoding.HTML.Encode(Value);
      Token := #$E000 + IntToStr(Index) + #$E001;
      if Pos(Value, Result) > 0 then
        Result := StringReplace(Result, Value, Token, [rfReplaceAll]);
    end;
    if IsHtml then Result := FReportHtmlTranslator(Result)
    else Result := FReportTextTranslator(Result);
    for Index := 0 to High(ProtectedValues) do
    begin
      Value := ProtectedValues[Index];
      if IsHtml then Value := TNetEncoding.HTML.Encode(Value);
      Result := StringReplace(Result, #$E000 + IntToStr(Index) + #$E001, Value, [rfReplaceAll]);
    end;
  end;

  function IssueGroupKey(const AIssue: TConversionIssue): string;
  begin
    if SameText(AIssue.ProblemType, 'Mapping pack detection only') then
      Exit(IntToStr(Ord(AIssue.Severity)) + '|' +
        UpperCase(Trim(AIssue.ProblemType)) + '|' +
        BoolToStr(AIssue.IsBlocking, True));

    Result := IntToStr(Ord(AIssue.Severity)) + '|' +
      UpperCase(Trim(AIssue.ProblemType)) + '|' +
      UpperCase(Trim(AIssue.Message)) + '|' +
      UpperCase(Trim(AIssue.SuggestedFix)) + '|' +
      BoolToStr(AIssue.IsBlocking, True);
  end;

  function IsActionableInfo(const AIssue: TConversionIssue): Boolean;
  begin
    if AIssue.Severity <> csInfo then
      Exit(False);

    if SameText(AIssue.ProblemType, 'Dry-run preview') then
      Exit(False);

    Result := ((Trim(AIssue.ProblemType) <> '') or
       (Trim(AIssue.SuggestedFix) <> '') or
       AIssue.IsBlocking);
  end;

  function IsDryRunPreviewIssue(const AIssue: TConversionIssue): Boolean;
  begin
    Result := SameText(AIssue.ProblemType, 'Dry-run preview');
  end;
  function ShouldIncludeInDetailedIssues(const AIssue: TConversionIssue): Boolean;
  begin
    Result := (AIssue.Severity <> csManualReview) and
      ((AIssue.Severity <> csInfo) or IsActionableInfo(AIssue));
  end;

  procedure TrackAffectedFile(const AIssue: TConversionIssue);
  var
    FileKey: string;
  begin
    if Trim(AIssue.FileName) = '' then
      Exit;

    FileKey := UpperCase(Trim(AIssue.FileName));
    if AffectedFiles.IndexOf(FileKey) = -1 then
      AffectedFiles.Add(FileKey);
  end;

  function IssueRiskCategory(const AIssue: TConversionIssue): string;
  begin
    if AIssue.IsBlocking or (AIssue.Severity in [csError, csCritical]) then
      Exit('Compile or conversion blocker');

    if ContainsText(AIssue.ProblemType, 'Graphics') or
       ContainsText(AIssue.ProblemType, 'GDI') or
       ContainsText(AIssue.Message, 'Canvas') or
       ContainsText(AIssue.Message, 'drawing') then
      Exit('Visual review risk');

    if ContainsText(AIssue.ProblemType, 'Windows') or
       ContainsText(AIssue.ProblemType, 'message') or
       ContainsText(AIssue.Message, 'Windows') or
       ContainsText(AIssue.Message, 'message') then
      Exit('Runtime behavior risk');

    if ContainsText(AIssue.ProblemType, 'Data') or
       ContainsText(AIssue.ProblemType, 'LiveBindings') then
      Exit('Data binding review risk');

    if AIssue.Severity = csManualReview then
      Exit('Manual code review');
    if AIssue.Severity = csWarning then
      Exit('Warning review');

    Result := 'Information';
  end;

  function HasRiskCategory(const ARiskText: string): Boolean;
  var
    RiskIssue: TConversionIssue;
  begin
    Result := False;
    for RiskIssue in FContext.Issues do
      if SameText(IssueRiskCategory(RiskIssue), ARiskText) then
        Exit(True);
  end;

  function BuildNextStepText: string;
  begin
    if HasBlockingOutcome then
      Result := 'Open the report, resolve blocking items and file-level conversion failures first, then reopen the generated project in the IDE.'
    else if ManualCount > 0 then
      Result := 'Open the grouped manual-review section, inspect each affected file in the IDE, and apply the required FMX decisions before relying on the output.'
    else if VisibleIssueCount > 0 then
      Result := 'Open the report for a quick sanity check, review the remaining warnings, and then compile the generated project in the IDE.'
    else
      Result := 'Open the report for a final sanity check, then compile and smoke-test the generated project in the IDE.';
  end;

  procedure AddManualIssueToGroup(const AIssue: TConversionIssue);
  var
    Key: string;
    Index: Integer;
    GroupItems: TList<TConversionIssue>;
  begin
    Key := IssueGroupKey(AIssue);
    Index := ManualGroups.IndexOf(Key);
    if Index = -1 then
    begin
      GroupItems := TList<TConversionIssue>.Create;
      ManualGroups.AddObject(Key, GroupItems);
    end
    else
      GroupItems := TList<TConversionIssue>(ManualGroups.Objects[Index]);

    GroupItems.Add(AIssue);
  end;

  function BuildOccurrenceText(const AIssues: TList<TConversionIssue>): string;
  var
    GroupIssue: TConversionIssue;
    Occurrences: TStringList;
    Occurrence: string;
    LastFile: string;
    FirstCode: string;
    StartLine: Integer;
    EndLine: Integer;
    BlockLineCount: Integer;
    HasBlock: Boolean;

    function UsesCollapsedLineRanges: Boolean;
    var
      PrevIssue: TConversionIssue;
      TestIssue: TConversionIssue;
    begin
      Result := False;
      PrevIssue := nil;
      for TestIssue in AIssues do
      begin
        if Assigned(PrevIssue) and
           SameText(TestIssue.FileName, PrevIssue.FileName) and
           (TestIssue.LineNumber > 0) and
           ((TestIssue.LineNumber = PrevIssue.LineNumber) or
            (TestIssue.LineNumber = PrevIssue.LineNumber + 1)) and
           (Trim(TestIssue.OriginalCode) <> '') then
          Exit(True);
        PrevIssue := TestIssue;
      end;
    end;

    procedure FlushBlock;
    begin
      if not HasBlock then
        Exit;

      if StartLine = EndLine then
        Occurrence := Format('%s:%d', [LastFile, StartLine])
      else
        Occurrence := Format('%s:%d-%d (%d lines)',
          [LastFile, StartLine, EndLine, BlockLineCount]);

      if Trim(FirstCode) <> '' then
        Occurrence := Occurrence + ' -> ' + Trim(FirstCode);

      if Occurrences.IndexOf(Occurrence) = -1 then
        Occurrences.Add(Occurrence);

      HasBlock := False;
      LastFile := '';
      FirstCode := '';
      StartLine := -1;
      EndLine := -1;
      BlockLineCount := 0;
    end;
  begin
    Result := '';
    Occurrences := TStringList.Create;
    try
      if UsesCollapsedLineRanges then
      begin
        HasBlock := False;
        LastFile := '';
        FirstCode := '';
        StartLine := -1;
        EndLine := -1;
        BlockLineCount := 0;

        for GroupIssue in AIssues do
        begin
          if (Trim(GroupIssue.FileName) = '') or
             (GroupIssue.LineNumber <= 0) or
             (Trim(GroupIssue.OriginalCode) = '') then
            Continue;

          if HasBlock and SameText(GroupIssue.FileName, LastFile) and
             (GroupIssue.LineNumber <= EndLine + 1) then
          begin
            EndLine := Max(EndLine, GroupIssue.LineNumber);
            Inc(BlockLineCount);
            Continue;
          end;

          FlushBlock;
          HasBlock := True;
          LastFile := GroupIssue.FileName;
          FirstCode := GroupIssue.OriginalCode;
          StartLine := GroupIssue.LineNumber;
          EndLine := GroupIssue.LineNumber;
          BlockLineCount := 1;
        end;

        FlushBlock;
      end
      else
      begin
        for GroupIssue in AIssues do
        begin
          Occurrence := '';
          if GroupIssue.FileName <> '' then
            Occurrence := GroupIssue.FileName;
          if GroupIssue.LineNumber > 0 then
            Occurrence := Occurrence + ':' + IntToStr(GroupIssue.LineNumber);
          if Trim(GroupIssue.OriginalCode) <> '' then
            Occurrence := Occurrence + ' -> ' + Trim(GroupIssue.OriginalCode);
          if Occurrence = '' then
            Occurrence := GroupIssue.Message;

          if Occurrences.IndexOf(Occurrence) = -1 then
            Occurrences.Add(Occurrence);
        end;
      end;

      Result := TrimRight(Occurrences.Text);
    finally
      Occurrences.Free;
    end;
  end;

  function ManualOccurrenceCount(const AIssues: TList<TConversionIssue>): Integer;
  var
    OccurrenceText: string;
    Occurrences: TStringList;
  begin
    OccurrenceText := BuildOccurrenceText(AIssues);
    if Trim(OccurrenceText) = '' then
      Exit(0);

    Occurrences := TStringList.Create;
    try
      Occurrences.Text := OccurrenceText;
      Result := Occurrences.Count;
    finally
      Occurrences.Free;
    end;
  end;

  function ManualAffectedLineCount(const AIssues: TList<TConversionIssue>): Integer;
  var
    GroupIssue: TConversionIssue;
    LinesSeen: TStringList;
    Key: string;
  begin
    Result := 0;
    if (AIssues.Count = 0) or
       not SameText(AIssues[0].ProblemType, 'Windows messages or message handlers') then
      Exit;

    LinesSeen := TStringList.Create;
    try
      for GroupIssue in AIssues do
      begin
        if (Trim(GroupIssue.FileName) = '') or
           (GroupIssue.LineNumber <= 0) or
           (Trim(GroupIssue.OriginalCode) = '') then
          Continue;

        Key := UpperCase(Trim(GroupIssue.FileName)) + ':' + IntToStr(GroupIssue.LineNumber);
        if LinesSeen.IndexOf(Key) = -1 then
          LinesSeen.Add(Key);
      end;
      Result := LinesSeen.Count;
    finally
      LinesSeen.Free;
    end;
  end;

  function BuildManualDetailText(const AIssues: TList<TConversionIssue>): string;
  var
    FirstIssue: TConversionIssue;
  begin
    if AIssues.Count = 0 then
      Exit('');

    FirstIssue := AIssues[0];
    if SameText(FirstIssue.ProblemType, 'Mapping pack detection only') and
       (AIssues.Count > 1) then
      Result := Format('%d mapping-pack detect-only components were found; no FMX replacements were generated.',
        [AIssues.Count])
    else
      Result := FirstIssue.Message;
  end;

  function BuildSuggestedFixText(const AIssues: TList<TConversionIssue>): string;
  var
    GroupIssue: TConversionIssue;
    Fixes: TStringList;
  begin
    Result := '';
    Fixes := TStringList.Create;
    try
      for GroupIssue in AIssues do
        if (Trim(GroupIssue.SuggestedFix) <> '') and
           (Fixes.IndexOf(Trim(GroupIssue.SuggestedFix)) = -1) then
          Fixes.Add(Trim(GroupIssue.SuggestedFix));

      Result := TrimRight(Fixes.Text);
    finally
      Fixes.Free;
    end;

    if Result = '' then
      Result := 'Review this item in the IDE, choose the closest FMX equivalent, and apply manual fixes before relying on the generated output.';
  end;

  procedure FreeManualGroups;
  var
    I: Integer;
  begin
    for I := 0 to ManualGroups.Count - 1 do
      ManualGroups.Objects[I].Free;
  end;

  function FormatRunTime(Seconds: Integer): string;
  var
    Minutes: Integer;
    RemainingSeconds: Integer;
  begin
    if Seconds < 0 then
      Seconds := 0;
    if (Seconds = 0) and ((FFilesProcessed > 0) or (FFilesConverted > 0)) then
      Exit('< 1 second');

    Minutes := Seconds div 60;
    RemainingSeconds := Seconds mod 60;

    if Minutes > 0 then
    begin
      if RemainingSeconds = 0 then
        Result := Format('%d min', [Minutes])
      else
        Result := Format('%d min %d sec', [Minutes, RemainingSeconds]);
    end
    else if Seconds = 1 then
      Result := '1 sec'
    else
      Result := Format('%d sec', [Seconds]);
  end;

begin
  ReportModel.TextReportFile := TPath.Combine(FContext.Options.OutputPath, 'VCL_to_FMX_Conversion_Report.txt');
  ReportModel.HtmlReportFile := TPath.Combine(FContext.Options.OutputPath, 'VCL_to_FMX_Conversion_Report.html');
  ReportModel.JsonReportFile := TPath.Combine(FContext.Options.OutputPath, 'VCL_to_FMX_Conversion_Report.json');
  ReportModel.SourcePath := FContext.Options.SourcePath;
  ReportModel.OutputPath := FContext.Options.OutputPath;
  ReportModel.FilesProcessed := FFilesProcessed;
  ReportModel.FilesConverted := FFilesConverted;
  ReportModel.FilesWithErrors := FFilesErrors;
  ReportModel.FilesSkipped := FFilesSkipped;
  ReportModel.MappingPacksLoaded := FContext.LoadedMappingPacks.Count;
  Report := TStringList.Create;
  Html := TStringList.Create;
  SeenBlockingKeys := TStringList.Create;
  ManualGroups := TStringList.Create;
  ManualGroups.Sorted := True;
  ManualGroups.Duplicates := dupIgnore;
  AffectedFiles := TStringList.Create;
  try
    SeenBlockingKeys.Sorted := True;
    SeenBlockingKeys.Duplicates := dupIgnore;
    AffectedFiles.Sorted := True;
    AffectedFiles.Duplicates := dupIgnore;

    Duration := FEndTime - FStartTime;
    Secs := Round(Duration * 24 * 60 * 60);
    RunTimeText := FormatRunTime(Secs);
    ReportModel.RunTimeText := RunTimeText;

    InfoCount := 0;
    WarnCount := 0;
    ManualCount := 0;
    ManualIssueCount := 0;
    ErrorCount := 0;
    BlockingCount := 0;
    DryRunPreviewCount := 0;

    SetLength(ReportModel.Issues, FContext.Issues.Count);
    IssueIndex := 0;
    for Issue in FContext.Issues do
    begin
      ReportModel.Issues[IssueIndex] := TConversionReportIssue.Create(Issue,
        IssueRiskCategory(Issue), UpperCase(Trim(IssueRiskCategory(Issue))) +
        '|' + IssueGroupKey(Issue) + '|' +
        UpperCase(Trim(Issue.FileName)) + '|' + IntToStr(Issue.LineNumber) +
        '|' + UpperCase(Trim(Issue.OriginalCode)));
      ReportModel.Issues[IssueIndex].IncludeInDetailedIssues :=
        ShouldIncludeInDetailedIssues(Issue);
      ReportModel.Issues[IssueIndex].IsDryRunPreview :=
        IsDryRunPreviewIssue(Issue);
      ReportModel.Issues[IssueIndex].IsActionableInfo :=
        IsActionableInfo(Issue);
      ReportModel.Issues[IssueIndex].SeverityText :=
        SeverityToString(Issue.Severity);
      Inc(IssueIndex);

      if IsDryRunPreviewIssue(Issue) then
        Inc(DryRunPreviewCount);

      case Issue.Severity of
        csInfo:
          if IsActionableInfo(Issue) then
            Inc(InfoCount);
        csWarning: Inc(WarnCount);
        csManualReview:
          begin
            Inc(ManualIssueCount);
            AddManualIssueToGroup(Issue);
          end;
        csError, csCritical: Inc(ErrorCount);
      end;

      if (Issue.Severity = csManualReview) or ShouldIncludeInDetailedIssues(Issue) then
        TrackAffectedFile(Issue);

      if Issue.IsBlocking or (Issue.Severity in [csError, csCritical]) then
        if SeenBlockingKeys.IndexOf(IssueGroupKey(Issue)) = -1 then
        begin
          SeenBlockingKeys.Add(IssueGroupKey(Issue));
          Inc(BlockingCount);
        end;
    end;

    ManualCount := ManualGroups.Count;

    VisibleIssueCount := WarnCount + ManualIssueCount + ErrorCount;
    HasBlockingOutcome := (FFilesErrors > 0) or (BlockingCount > 0);
    NextStepText := BuildNextStepText;

    if HasBlockingOutcome then
      StatusText := 'Blocking issues present'
    else if ManualCount > 0 then
      StatusText := 'Manual review required'
    else
      StatusText := 'Clean conversion';

    ReportModel.InformationalCount := InfoCount;
    ReportModel.WarningCount := WarnCount;
    ReportModel.ManualIssueCount := ManualIssueCount;
    ReportModel.ManualGroupCount := ManualCount;
    ReportModel.ErrorCount := ErrorCount;
    ReportModel.BlockingCount := BlockingCount;
    ReportModel.DryRunPreviewCount := DryRunPreviewCount;
    ReportModel.VisibleIssueCount := VisibleIssueCount;
    ReportModel.AffectedFileCount := AffectedFiles.Count;
    ReportModel.HasBlockingOutcome := HasBlockingOutcome;
    ReportModel.StatusText := StatusText;
    ReportModel.NextStepText := NextStepText;
    ReportModel.NeedsRuntimeReview := HasRiskCategory('Runtime behavior risk');
    ReportModel.NeedsVisualReview := HasRiskCategory('Visual review risk');
    ReportModel.NeedsDataBindingReview := HasRiskCategory('Data binding review risk');
    ReportModel.NeedsManualCodeReview := ManualCount > 0;
    SetLength(ReportModel.MappingPacks, FContext.LoadedMappingPacks.Count);
    for ManualIndex := 0 to FContext.LoadedMappingPacks.Count - 1 do
      ReportModel.MappingPacks[ManualIndex] :=
        FContext.LoadedMappingPacks[ManualIndex];
    SetLength(ReportModel.MappingUsages, FContext.MappingPackUsages.Count);
    for ManualIndex := 0 to FContext.MappingPackUsages.Count - 1 do
      ReportModel.MappingUsages[ManualIndex] :=
        TConversionReportMappingUsage.Create(
          FContext.MappingPackUsages[ManualIndex]);
    SetLength(ReportModel.ManualGroups, ManualGroups.Count);
    for ManualIndex := 0 to ManualGroups.Count - 1 do
    begin
      Issue := TList<TConversionIssue>(ManualGroups.Objects[ManualIndex])[0];
      ReportModel.ManualGroups[ManualIndex].Title :=
        IfThen(Issue.ProblemType <> '', Issue.ProblemType,
          'Manual review required');
      ReportModel.ManualGroups[ManualIndex].RiskCategory :=
        IssueRiskCategory(Issue);
      ReportModel.ManualGroups[ManualIndex].OccurrenceCount :=
        ManualOccurrenceCount(
          TList<TConversionIssue>(ManualGroups.Objects[ManualIndex]));
      ReportModel.ManualGroups[ManualIndex].AffectedLineCount :=
        ManualAffectedLineCount(
          TList<TConversionIssue>(ManualGroups.Objects[ManualIndex]));
      ReportModel.ManualGroups[ManualIndex].DetailText :=
        BuildManualDetailText(
          TList<TConversionIssue>(ManualGroups.Objects[ManualIndex]));
      ReportModel.ManualGroups[ManualIndex].AffectedLocations :=
        BuildOccurrenceText(
          TList<TConversionIssue>(ManualGroups.Objects[ManualIndex]));
      ReportModel.ManualGroups[ManualIndex].RecommendedSolution :=
        BuildSuggestedFixText(
          TList<TConversionIssue>(ManualGroups.Objects[ManualIndex]));
      ReportModel.ManualGroups[ManualIndex].IsBlocking := Issue.IsBlocking;
    end;
    SetLength(ReportModel.ConversionLogLines, FConversionLog.Count);
    for ManualIndex := 0 to FConversionLog.Count - 1 do
      ReportModel.ConversionLogLines[ManualIndex] := FConversionLog[ManualIndex];

    if Assigned(FReportTextTranslator) or Assigned(FReportHtmlTranslator) then
    begin
      ProtectedData := TStringList.Create;
      try
        ProtectedData.CaseSensitive := True;
        ProtectedData.Sorted := True;
        ProtectedData.Duplicates := dupIgnore;
        ProtectedData.AddStrings([ReportModel.SourcePath, ReportModel.OutputPath,
          ReportModel.TextReportFile, ReportModel.HtmlReportFile, ReportModel.JsonReportFile]);
        for Issue in FContext.Issues do
        begin
          ProtectedData.AddStrings([Issue.FileName, ExtractFileName(Issue.FileName), Issue.OriginalCode]);
          ProtectedData.AddStrings(Issue.OriginalCode.Split([sLineBreak]));
        end;
        for ManualIndex := 0 to High(ReportModel.MappingUsages) do
          with ReportModel.MappingUsages[ManualIndex] do
            ProtectedData.AddStrings([ComponentName, VCLClassName, FMXClassName, SourceFile, PackName, Vendor]);
        ProtectedValues := ProtectedData.ToStringArray;
      finally ProtectedData.Free; end;
      TArray.Sort<string>(ProtectedValues, TComparer<string>.Construct(
        function(const Left, Right: string): Integer
        begin Result := Length(Right) - Length(Left); end));
    end;
    TConversionTextReportRenderer.Render(ReportModel, Report);
    if Assigned(FReportTextTranslator) then
      for ReportLine := 0 to Report.Count - 1 do
        Report[ReportLine] := TranslateReportPresentation(Report[ReportLine], False);
    Report.SaveToFile(ReportModel.TextReportFile, TEncoding.UTF8);
    FTextReportPath := ReportModel.TextReportFile;

    UILog(Format(SDisplayReportSavedToS, [ReportModel.TextReportFile]));
    SetLength(ReportModel.ConversionLogLines, FConversionLog.Count);
    for ManualIndex := 0 to FConversionLog.Count - 1 do
      ReportModel.ConversionLogLines[ManualIndex] := FConversionLog[ManualIndex];

    AddHtmlReportDocumentHead(Html);
    TConversionHtmlReportRenderer.RenderBody(ReportModel, Html);
    if Assigned(FReportHtmlTranslator) then
    begin
      Html.Text := StringReplace(Html.Text, '<html lang="en">',
        '<html lang="' + TNetEncoding.HTML.Encode(FReportLanguageCode) +
        '" dir="' + TNetEncoding.HTML.Encode(FReportTextDirection) + '">', []);
      Html.Text := TranslateReportPresentation(Html.Text, True);
    end;
    Html.SaveToFile(ReportModel.HtmlReportFile, TEncoding.UTF8);
    FHtmlReportPath := ReportModel.HtmlReportFile;
    UILog(Format(SDisplayHtmlReportSavedToS, [ReportModel.HtmlReportFile]));
    TConversionJsonReportRenderer.Save(ReportModel);
    UILog(Format(SDisplayJsonReportSavedToS, [ReportModel.JsonReportFile]));

  finally
    AffectedFiles.Free;
    FreeManualGroups;
    ManualGroups.Free;
    SeenBlockingKeys.Free;
    Html.Free;
    Report.Free;
  end;
end;

procedure TConverterEngine.Cancel;
begin
  FCancelled := True;
  UILog(SDisplayConversionCancelledByUser);
end;

end.
