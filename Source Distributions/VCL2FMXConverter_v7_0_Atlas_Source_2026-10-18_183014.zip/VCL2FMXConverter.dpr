﻿program VCL2FMXConverter;

uses
  System.StartUpCopy,
  FMX.Forms,
  MainForm in 'MainForm.pas' {frmMain},
  Converter.Advanced.CriticalAreas in 'Converter.Advanced.CriticalAreas.pas',
  Converter.Advanced.DataAware in 'Converter.Advanced.DataAware.pas',
  Converter.Advanced.ThirdParty in 'Converter.Advanced.ThirdParty.pas',
  Converter.Advanced.WinAPI in 'Converter.Advanced.WinAPI.pas',
  Converter.Core.Engine in 'Converter.Core.Engine.pas',
  Converter.Core.FileManager in 'Converter.Core.FileManager.pas',
  Converter.Core.Integration in 'Converter.Core.Integration.pas',
  Converter.Core.Types in 'Converter.Core.Types.pas',
  Converter.Mapper.Component in 'Converter.Mapper.Component.pas',
  Converter.Mapper.Catalog in 'Converter.Mapper.Catalog.pas',
  Converter.Parser.DFM in 'Converter.Parser.DFM.pas',
  Converter.Generator.FMX in 'Converter.Generator.FMX.pas',
  Converter.Parser.Pascal in 'Converter.Parser.Pascal.pas',
  Converter.Project.Generator in 'Converter.Project.Generator.pas',
  Converter.Reporting.Html in 'Converter.Reporting.Html.pas',
  Converter.Reporting.Json in 'Converter.Reporting.Json.pas',
  Converter.Reporting.Model in 'Converter.Reporting.Model.pas',
  Converter.Reporting.Text in 'Converter.Reporting.Text.pas',
  Converter.Rewrite.AutoFixes in 'Converter.Rewrite.AutoFixes.pas',
  Converter.Rewrite.Compatibility in 'Converter.Rewrite.Compatibility.pas',
  Converter.Rewrite.LiveBindings in 'Converter.Rewrite.LiveBindings.pas',
  Converter.Rewrite.RuntimeNormalization in 'Converter.Rewrite.RuntimeNormalization.pas',
  Converter.Rewrite.UsesClause in 'Converter.Rewrite.UsesClause.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TfrmMain, frmMain);
  Application.Run;
end.
